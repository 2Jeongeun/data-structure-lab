set(__QT_DEPLOY_TARGET_datastructure_gui_FILE C:/Users/이정응/Documents/카카오톡 받은 파일/ds-project/ds-project/build-win/datastructure_gui.exe)
set(__QT_DEPLOY_TARGET_datastructure_gui_TYPE EXECUTABLE)
set(__QT_DEPLOY_TARGET_datastructure_gui_RUNTIME_DLLS C:/msys64/ucrt64/bin/libcurl-4.dll;C:/msys64/ucrt64/bin/Qt6Widgets.dll;C:/msys64/ucrt64/bin/Qt6Gui.dll;C:/msys64/ucrt64/bin/Qt6Core.dll)
