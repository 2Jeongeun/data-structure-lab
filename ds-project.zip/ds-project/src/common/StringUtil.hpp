#pragma once

#include <algorithm>
#include <cctype>
#include <string>
#include <vector>

namespace common {

inline std::string trim(const std::string& s) {
    auto begin = std::find_if_not(s.begin(), s.end(), [](unsigned char c) {
        return std::isspace(c);
    });
    auto end = std::find_if_not(s.rbegin(), s.rend(), [](unsigned char c) {
        return std::isspace(c);
    }).base();
    return begin < end ? std::string(begin, end) : "";
}

inline std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return s;
}

inline std::string upper(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
        return static_cast<char>(std::toupper(c));
    });
    return s;
}

inline std::string join(const std::vector<std::string>& values,
                        const std::string& delimiter) {
    std::string out;
    for (size_t i = 0; i < values.size(); ++i) {
        out += values[i];
        if (i + 1 < values.size()) {
            out += delimiter;
        }
    }
    return out;
}

}  // namespace common
