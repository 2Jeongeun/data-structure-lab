#pragma once

#include <algorithm>
#include <string>
#include <vector>

#include "StringUtil.hpp"

namespace common {

// AI 모델이 반환한 {"keywords": [...]} 형태의 응답에서 중복 없는 키워드 목록을 뽑는다.
// 프로젝트 규모를 고려해 외부 JSON 파서 대신 필요한 배열 부분만 가볍게 처리한다.
inline std::vector<std::string> parseKeywordJson(const std::string& json) {
    std::vector<std::string> result;
    size_t keyPos = json.find("\"keywords\"");
    if (keyPos == std::string::npos) return result;

    size_t leftBracket = json.find('[', keyPos);
    if (leftBracket == std::string::npos) return result;

    size_t rightBracket = json.find(']', leftBracket);
    if (rightBracket == std::string::npos) rightBracket = json.size();

    size_t pos = leftBracket + 1;
    while (pos < rightBracket) {
        // 배열 안의 문자열 값만 차례대로 읽고 공백 제거 후 중복을 건너뛴다.
        size_t openQuote = json.find('"', pos);
        if (openQuote == std::string::npos || openQuote >= rightBracket) break;

        size_t closeQuote = openQuote + 1;
        std::string value;
        while (closeQuote < json.size()) {
            if (json[closeQuote] == '"' && json[closeQuote - 1] != '\\') break;
            value += json[closeQuote];
            ++closeQuote;
        }

        std::string trimmed = trim(value);
        if (!trimmed.empty() &&
            std::find(result.begin(), result.end(), trimmed) == result.end()) {
            result.push_back(trimmed);
        }

        pos = closeQuote + 1;
    }

    return result;
}
}
