#pragma once

#include <filesystem>
#include <sqlite3.h>
#include <string>

#include "../errorHandler/ErrorHandler.hpp"

namespace sqlite_utils {

struct Statement {
    sqlite3_stmt* stmt = nullptr;

    Statement(sqlite3* db, const std::string& sql) {
        if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
            throw DatabaseException(
                "Failed to prepare statement: " + std::string(sqlite3_errmsg(db)));
        }
    }

    ~Statement() {
        if (stmt) {
            sqlite3_finalize(stmt);
        }
    }

    Statement(const Statement&) = delete;
    Statement& operator=(const Statement&) = delete;
};

struct Transaction {
    sqlite3* db;
    bool committed = false;

    explicit Transaction(sqlite3* handle) : db(handle) {
        char* error = nullptr;
        if (sqlite3_exec(db, "BEGIN TRANSACTION;", nullptr, nullptr, &error) != SQLITE_OK) {
            std::string message =
                "Failed to begin transaction: " + std::string(error ? error : "unknown");
            if (error) {
                sqlite3_free(error);
            }
            throw DatabaseException(message);
        }
    }

    ~Transaction() {
        if (!committed && db) {
            sqlite3_exec(db, "ROLLBACK;", nullptr, nullptr, nullptr);
        }
    }

    void commit() {
        if (committed || !db) {
            return;
        }

        char* error = nullptr;
        if (sqlite3_exec(db, "COMMIT;", nullptr, nullptr, &error) != SQLITE_OK) {
            std::string message =
                "Failed to commit transaction: " + std::string(error ? error : "unknown");
            if (error) {
                sqlite3_free(error);
            }
            throw DatabaseException(message);
        }
        committed = true;
    }
};

inline void openDatabase(sqlite3*& db,
                         const std::string& path,
                         const std::string& label) {
    std::filesystem::path dbPath(path);
    if (dbPath.has_parent_path()) {
        std::filesystem::create_directories(dbPath.parent_path());
    }

    if (sqlite3_open(path.c_str(), &db) != SQLITE_OK) {
        std::string error = "Cannot open " + label + " database: ";
        if (db) {
            error += sqlite3_errmsg(db);
            sqlite3_close(db);
            db = nullptr;
        } else {
            error += "Out of memory";
        }
        throw DatabaseException(error);
    }

    sqlite3_exec(db, "PRAGMA foreign_keys = ON;", nullptr, nullptr, nullptr);
}

inline void exec(sqlite3* db, const std::string& sql, const std::string& context) {
    char* error = nullptr;
    if (sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &error) != SQLITE_OK) {
        std::string message = context + ": " + std::string(error ? error : "unknown");
        if (error) {
            sqlite3_free(error);
        }
        throw DatabaseException(message);
    }
}

inline std::string columnText(sqlite3_stmt* stmt, int index) {
    const char* value =
        reinterpret_cast<const char*>(sqlite3_column_text(stmt, index));
    return value ? value : "";
}

inline void reset(Statement& stmt) {
    sqlite3_reset(stmt.stmt);
    sqlite3_clear_bindings(stmt.stmt);
}

}  // namespace sqlite_utils
