#pragma once
#include <string>
#include <fstream>
#include <sstream>

// data/key.json에서 API 키 같은 민감 설정을 간단히 읽어 오는 유틸리티다.
// 외부 JSON 라이브러리를 추가하지 않기 위해 필요한 문자열 필드만 직접 찾는다.
namespace KeyConfig {
inline std::string get(const std::string& field,
                       const std::string& path = "data/key.json") {
    std::ifstream file(path);
    if (!file.is_open()) return "";

    std::stringstream buffer;
    buffer << file.rdbuf();
    const std::string json = buffer.str();

    // "field": "value" 형태의 단순 JSON 값을 찾아 반환한다.
    const std::string needle = "\"" + field + "\"";
    size_t keyPos = json.find(needle);
    if (keyPos == std::string::npos) return "";

    size_t colonPos = json.find(':', keyPos + needle.size());
    if (colonPos == std::string::npos) return "";

    size_t openQuote = json.find('"', colonPos);
    if (openQuote == std::string::npos) return "";

    size_t pos = openQuote + 1;
    while (pos < json.size()) {
        if (json[pos] == '"' && json[pos - 1] != '\\') break;
        ++pos;
    }
    if (pos >= json.size()) return "";

    return json.substr(openQuote + 1, pos - openQuote - 1);
}
}
