#pragma once
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <utility>

// data/prompt.json에 저장된 프롬프트 템플릿을 읽고 변수 치환을 수행한다.
namespace PromptConfig {
// JSON 문자열 안의 \n, \t 같은 이스케이프 문자를 실제 문자로 되돌린다.
inline std::string unescape(const std::string& input) {
    std::string out;
    out.reserve(input.size());
    for (size_t i = 0; i < input.size(); ++i) {
        if (input[i] == '\\' && i + 1 < input.size()) {
            char next = input[i + 1];
            switch (next) {
                case 'n': out += '\n'; break;
                case 't': out += '\t'; break;
                case 'r': out += '\r'; break;
                case '"': out += '"';  break;
                case '\\': out += '\\'; break;
                case '/': out += '/';  break;
                default: out += next;  break;
            }
            ++i;
        } else {
            out += input[i];
        }
    }
    return out;
}

// 지정한 이름의 프롬프트 템플릿을 파일에서 찾아 읽는다.
inline std::string get(const std::string& name,
                       const std::string& path = "data/prompt.json") {
    std::ifstream file(path);
    if (!file.is_open()) return "";

    std::stringstream buffer;
    buffer << file.rdbuf();
    const std::string json = buffer.str();

    const std::string needle = "\"" + name + "\"";
    size_t keyPos = json.find(needle);
    if (keyPos == std::string::npos) return "";

    size_t colonPos = json.find(':', keyPos + needle.size());
    if (colonPos == std::string::npos) return "";

    size_t openQuote = json.find('"', colonPos);
    if (openQuote == std::string::npos) return "";

    size_t pos = openQuote + 1;
    while (pos < json.size()) {
        if (json[pos] == '"' && json[pos - 1] != '\\') break;
        ++pos;
    }
    if (pos >= json.size()) return "";

    return unescape(json.substr(openQuote + 1, pos - openQuote - 1));
}

// 템플릿 문자열 안의 {변수명} 토큰을 실제 값으로 치환한다.
inline std::string render(const std::string& templ,
                          const std::vector<std::pair<std::string, std::string>>& vars) {
    std::string result = templ;
    for (const auto& kv : vars) {
        const std::string token = "{" + kv.first + "}";
        size_t pos = 0;
        while ((pos = result.find(token, pos)) != std::string::npos) {
            result.replace(pos, token.size(), kv.second);
            pos += kv.second.size();
        }
    }
    return result;
}

// 템플릿 로드와 변수 치환을 한 번에 수행하는 편의 함수다.
inline std::string build(const std::string& name,
                         const std::vector<std::pair<std::string, std::string>>& vars,
                         const std::string& path = "data/prompt.json") {
    return render(get(name, path), vars);
}
}
