#include "../dialogs/AddSymbolDialog.hpp"
#include "../dialogs/EditKeywordsDialog.hpp"
#include "../shared/QtString.hpp"
#include "WishlistPage.hpp"
#include "../shared/Theme.hpp"
#include "../../common/StringUtil.hpp"
#include "../../errorHandler/ErrorHandler.hpp"
#include <QCheckBox>
#include <QColor>
#include <QFrame>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QTableWidget>
#include <QVBoxLayout>

WishlistPage::WishlistPage(SymbolListManager& manager, MarketCatalogService& marketService, WishlistWorkflowService& wishlistService, QWidget* parent)
    : QWidget(parent), manager_(manager), marketService_(marketService), wishlistService_(wishlistService) {
    // 위시리스트 표와 액션 버튼을 한 화면에서 관리하는 페이지다.
    auto* root = new QVBoxLayout(this); root->setContentsMargins(28, 22, 28, 22); root->setSpacing(18);
    auto* tableCard = new QFrame(this); tableCard->setObjectName("TableCard"); auto* cardLay = new QVBoxLayout(tableCard); cardLay->setContentsMargins(18, 18, 18, 18); cardLay->setSpacing(12);
    auto* eyebrow = new QLabel("CURRENT WATCHLIST", this); eyebrow->setObjectName("Eyebrow"); auto* title = new QLabel("Selected Symbols", this); title->setObjectName("PanelTitle"); auto* meta = new QLabel("Use the checkbox column for fast mouse-based bulk actions.", this); meta->setObjectName("PanelMeta"); cardLay->addWidget(eyebrow); cardLay->addWidget(title); cardLay->addWidget(meta);
    table_ = new QTableWidget(tableCard); table_->setColumnCount(5); table_->setHorizontalHeaderLabels({"", "NAME", "CODE", "MARKET", "KEYWORDS"}); table_->horizontalHeader()->setStretchLastSection(true); table_->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents); table_->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents); table_->setColumnWidth(0, 44); table_->verticalHeader()->setVisible(false); table_->setShowGrid(false); table_->setSelectionBehavior(QAbstractItemView::SelectRows); table_->setSelectionMode(QAbstractItemView::SingleSelection); table_->setEditTriggers(QAbstractItemView::NoEditTriggers); cardLay->addWidget(table_, 1);
    auto* row = new QHBoxLayout(); auto* hint = new QLabel("Tip: check multiple rows, then remove them in one pass.", this); hint->setObjectName("PanelMeta"); row->addWidget(hint); row->addStretch(1); openAddBtn_ = new QPushButton("Add Symbol", this); openAddBtn_->setObjectName("Primary"); editKeywordsBtn_ = new QPushButton("Edit Keywords", this); removeBtn_ = new QPushButton("Checked Items Delete", this); removeBtn_->setObjectName("Danger"); for (auto* btn : {openAddBtn_, editKeywordsBtn_, removeBtn_}) row->addWidget(btn); cardLay->addLayout(row); root->addWidget(tableCard, 1);
    hint_ = new QLabel("Use Add Symbol to open a larger market search popup.", this); hint_->setObjectName("PanelMeta"); root->addWidget(hint_);
    connect(removeBtn_, &QPushButton::clicked, this, &WishlistPage::onRemove); connect(openAddBtn_, &QPushButton::clicked, this, &WishlistPage::onOpenAddDialog); connect(editKeywordsBtn_, &QPushButton::clicked, this, &WishlistPage::onEditKeywords); refreshTable();
}

Symbol WishlistPage::currentSelectedSymbol() const {
    int row = table_->currentRow(); if (row < 0) return Symbol(-1, "", "", "", {});
    auto* item = table_->item(row, 1); if (!item) return Symbol(-1, "", "", "", {});
    int symbolId = item->data(Qt::UserRole).toInt(); for (const auto& symbol : manager_.getWishlist()) if (symbol.id == symbolId) return symbol; return Symbol(-1, "", "", "", {});
}

void WishlistPage::refreshTable() {
    auto list = manager_.getWishlist(); table_->setRowCount(static_cast<int>(list.size()));
    for (int i = 0; i < static_cast<int>(list.size()); ++i) {
        // 각 행의 체크박스에는 실제 DB id를 숨겨 두어 다중 삭제에 활용한다.
        const Symbol& s = list[i]; auto* box = new QCheckBox(table_); box->setProperty("symbolId", s.id); auto* wrap = new QWidget(table_); auto* layout = new QHBoxLayout(wrap); layout->setContentsMargins(6, 4, 6, 4); layout->setAlignment(Qt::AlignCenter); layout->addWidget(box); wrap->setMinimumWidth(36); table_->setCellWidget(i, 0, wrap);
        auto* name = new QTableWidgetItem(qs(s.name)); name->setData(Qt::UserRole, s.id); table_->setItem(i, 1, name);
        auto* code = new QTableWidgetItem(qs(s.code)); code->setForeground(QColor(Theme::Color::InkSubtle)); table_->setItem(i, 2, code);
        auto* market = new QTableWidgetItem(qs(s.market).toUpper()); market->setForeground(QColor(Theme::Color::Accent)); table_->setItem(i, 3, market);
        auto* kw = new QTableWidgetItem(qs(common::join(s.keywords, "  ·  "))); kw->setForeground(QColor(Theme::Color::InkSubtle)); table_->setItem(i, 4, kw); table_->setRowHeight(i, 48);
    }
}

void WishlistPage::onRemove() {
    std::vector<int> ids; ids.reserve(table_->rowCount());
    for (int row = 0; row < table_->rowCount(); ++row) { QWidget* wrap = table_->cellWidget(row, 0); if (!wrap) continue; QCheckBox* box = wrap->findChild<QCheckBox*>(); if (box && box->isChecked()) ids.push_back(box->property("symbolId").toInt()); }
    if (ids.empty()) return void(ErrorHandler::showInfo(this, "삭제", "삭제할 종목을 체크하세요."));
    if (!ErrorHandler::confirm(this, "위시리스트 삭제", QString("%1개 종목을 삭제할까요?\n관련 고아 뉴스 캐시도 함께 정리됩니다.").arg(ids.size()))) return;
    // 종목 삭제와 함께 더 이상 연결되지 않는 뉴스 캐시도 정리한다.
    int purgedTerms = 0; for (int id : ids) purgedTerms += wishlistService_.removeSymbolAndPurgeNews(id).purgedTerms; refreshTable(); hint_->setText(QString("삭제 완료 · %1개 종목 제거, 고아 검색어 %2개 뉴스 정리됨").arg(ids.size()).arg(purgedTerms));
}

void WishlistPage::onOpenAddDialog() {
    AddSymbolDialog dialog(manager_, marketService_, wishlistService_, this);
    connect(&dialog, &AddSymbolDialog::symbolAdded, this, [this] { refreshTable(); hint_->setText("Symbol added to your watchlist."); });
    dialog.exec();
}

void WishlistPage::onEditKeywords() {
    Symbol symbol = currentSelectedSymbol(); if (symbol.id < 0) return void(ErrorHandler::showInfo(this, "Select a symbol", "키워드를 수정할 종목 행을 먼저 선택하세요."));
    EditKeywordsDialog dialog(symbol, wishlistService_, this); connect(&dialog, &EditKeywordsDialog::keywordsUpdated, this, [this, symbol] { refreshTable(); hint_->setText(QString("%1 keyword set updated.").arg(qs(symbol.name))); }); dialog.exec();
}
