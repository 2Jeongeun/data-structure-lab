#pragma once
#include <QFrame>
#include <QString>

class ArticleExcerptService;
class QLabel;
class QPushButton;
class QWidget;

// A single news article card. Clicking it expands the summary text provided by
// the Naver Search API (the article's description), with "요약 닫기" (close) and
// "링크 방문" (open link) actions. No network/AI call is involved.
class NewsCard : public QFrame {
    Q_OBJECT
public:
    NewsCard(const QString& term,
             const QString& title,
             const QString& date,
             const QString& description,
             const QString& link,
             const QString& originalLink,
             ArticleExcerptService* excerptService,
             QWidget* parent = nullptr);

protected:
    void mousePressEvent(QMouseEvent* event) override;

private:
    void toggleSummary();
    void loadExcerpt();

    QString link_;
    QString originalLink_;
    QString fallbackDescription_;
    QLabel* summaryLabel_ = nullptr;
    QWidget* summaryWrap_ = nullptr;
    ArticleExcerptService* excerptService_ = nullptr;
    bool excerptLoaded_ = false;
};
