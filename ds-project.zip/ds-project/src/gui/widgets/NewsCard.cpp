#include "NewsCard.hpp"
#include "../../errorHandler/ErrorHandler.hpp"
#include "../../service/news/ArticleExcerptService.hpp"
#include <QApplication>
#include <QDesktopServices>
#include <QHBoxLayout>
#include <QLabel>
#include <QMouseEvent>
#include <QPushButton>
#include <QUrl>
#include <QVBoxLayout>

// 뉴스 한 건을 카드 형태로 구성하고, 제목 클릭 시 원문 일부를 lazy load한다.
NewsCard::NewsCard(const QString& term,const QString& title,const QString& date,const QString& description,const QString& link,const QString& originalLink,ArticleExcerptService* excerptService,QWidget* parent):QFrame(parent),link_(link),originalLink_(originalLink),fallbackDescription_(description),excerptService_(excerptService){setObjectName("Card");auto* root=new QVBoxLayout(this);root->setContentsMargins(18,16,18,16);root->setSpacing(10);auto* top=new QHBoxLayout();top->setSpacing(8);auto* tag=new QLabel("# "+term,this);tag->setObjectName("TermTag");auto* dateLabel=new QLabel(date,this);dateLabel->setObjectName("CardMeta");top->addWidget(tag);top->addStretch(1);top->addWidget(dateLabel);root->addLayout(top);auto* titleButton=new QPushButton(title,this);titleButton->setObjectName("CardTitleButton");titleButton->setCursor(Qt::PointingHandCursor);titleButton->setFlat(true);root->addWidget(titleButton);auto* meta=new QHBoxLayout();meta->setSpacing(8);auto* hint=new QLabel("Click headline to load article excerpt",this);hint->setObjectName("CardMeta");meta->addWidget(hint);meta->addStretch(1);root->addLayout(meta);summaryWrap_=new QWidget(this);summaryWrap_->setObjectName("SummaryWrap");auto* s=new QVBoxLayout(summaryWrap_);s->setContentsMargins(12,12,12,12);s->setSpacing(10);summaryLabel_=new QLabel(description.trimmed().isEmpty()?"(제공된 요약 내용이 없습니다.)":description,summaryWrap_);summaryLabel_->setObjectName("Summary");summaryLabel_->setWordWrap(true);s->addWidget(summaryLabel_);auto* actions=new QHBoxLayout();actions->addStretch(1);auto* closeBtn=new QPushButton("요약 닫기",summaryWrap_);closeBtn->setObjectName("Ghost");auto* visitBtn=new QPushButton("링크 방문",summaryWrap_);visitBtn->setObjectName("Primary");actions->addWidget(closeBtn);actions->addWidget(visitBtn);s->addLayout(actions);summaryWrap_->setVisible(false);root->addWidget(summaryWrap_);connect(closeBtn,&QPushButton::clicked,this,[this]{summaryWrap_->setVisible(false);});connect(visitBtn,&QPushButton::clicked,this,[this]{auto dst=!originalLink_.isEmpty()?originalLink_:link_;if(!dst.isEmpty())QDesktopServices::openUrl(QUrl(dst));});connect(titleButton,&QPushButton::clicked,this,[this]{loadExcerpt();});}
void NewsCard::mousePressEvent(QMouseEvent* event){QFrame::mousePressEvent(event);}
void NewsCard::toggleSummary(){summaryWrap_->setVisible(!summaryWrap_->isVisible());}
void NewsCard::loadExcerpt(){if(!excerptLoaded_&&excerptService_){summaryLabel_->setText("원문 일부를 불러오는 중입니다…");QApplication::setOverrideCursor(Qt::WaitCursor);auto src=!originalLink_.isEmpty()?originalLink_:link_;std::string ex;try{ex=excerptService_->fetchExcerpt(src.toStdString());}catch(const std::exception& e){ErrorHandler::logError("News card excerpt loading failed: "+std::string(e.what()));}QApplication::restoreOverrideCursor();summaryLabel_->setText(!ex.empty()?QString::fromStdString(ex):fallbackDescription_.trimmed().isEmpty()?"(원문 일부를 가져오지 못했습니다. 링크 방문을 이용해 주세요.)":fallbackDescription_+"\n\n(원문 일부를 가져오지 못해 기본 요약을 표시합니다.)");excerptLoaded_=true;}toggleSummary();}
