#pragma once
#include <QWidget>
#include <vector>
#include <string>
#include "../../service/market/MarketCatalogService.hpp"
#include "../../service/wishlist/WishlistWorkflowService.hpp"
#include "../../symbolManage/SymbolListManager.hpp"

class QTableWidget;
class QPushButton;
class QLabel;

// 저장된 관심 종목을 표로 보여주고 추가, 삭제, 키워드 편집을 제공하는 페이지다.
class WishlistPage : public QWidget {
    Q_OBJECT
public:
    WishlistPage(SymbolListManager& manager,
                 MarketCatalogService& marketService,
                 WishlistWorkflowService& wishlistService,
                 QWidget* parent = nullptr);

public slots:
    // DB의 최신 위시리스트 내용을 다시 읽어 표를 갱신한다.
    void refreshTable();

private slots:
    // 선택한 종목 삭제, 추가 다이얼로그 열기, 키워드 편집을 처리한다.
    void onRemove();
    void onOpenAddDialog();
    void onEditKeywords();

private:
    // 현재 선택된 표 행을 Symbol 객체로 복원한다.
    Symbol currentSelectedSymbol() const;

    SymbolListManager& manager_;
    MarketCatalogService& marketService_;
    WishlistWorkflowService& wishlistService_;

    QTableWidget* table_ = nullptr;
    QPushButton* removeBtn_ = nullptr;
    QPushButton* openAddBtn_ = nullptr;
    QPushButton* editKeywordsBtn_ = nullptr;
    QLabel* hint_ = nullptr;
};
