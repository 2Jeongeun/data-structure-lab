#pragma once

#include <QDialog>

#include "../../service/market/MarketCatalogService.hpp"
#include "../../service/wishlist/WishlistWorkflowService.hpp"
#include "../../symbolManage/SymbolListManager.hpp"

class QComboBox;
class QLineEdit;
class QListWidget;
class QPushButton;
class QLabel;
class QListWidgetItem;

// 활성화된 시장 DB에서 종목을 검색하고 여러 종목을 한 번에 위시리스트에 추가하는 다이얼로그다.
class AddSymbolDialog : public QDialog {
    Q_OBJECT
public:
    AddSymbolDialog(SymbolListManager& manager,
                    MarketCatalogService& marketService,
                    WishlistWorkflowService& wishlistService,
                    QWidget* parent = nullptr);

signals:
    // 새 종목이 추가되면 부모 화면이 테이블을 새로고침할 수 있게 알린다.
    void symbolAdded();

private slots:
    // 시장/검색어 조건으로 종목 후보를 조회한다.
    void onSearch();
    // 체크된 종목들을 위시리스트에 추가하고 AI 키워드 생성을 시도한다.
    void onAdd();
    void onCheckedItemsChanged();
    void onItemActivated(QListWidgetItem* item);

private:
    // 체크박스 선택 수와 선택된 항목의 시각적 강조 상태를 계산한다.
    int checkedItemCount() const;
    void syncCheckedItemVisuals();

    SymbolListManager& manager_;
    MarketCatalogService& marketService_;
    WishlistWorkflowService& wishlistService_;

    QComboBox* marketBox_ = nullptr;
    QLineEdit* searchEdit_ = nullptr;
    QListWidget* results_ = nullptr;
    QPushButton* addBtn_ = nullptr;
    QLabel* hint_ = nullptr;
    QLabel* selectionPill_ = nullptr;
};
