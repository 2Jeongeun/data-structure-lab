#include "AddSymbolDialog.hpp"
#include "../shared/QtString.hpp"
#include "../shared/Theme.hpp"
#include "../../errorHandler/ErrorHandler.hpp"
#include <QApplication>
#include <QBrush>
#include <QComboBox>
#include <QFont>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QListWidgetItem>
#include <QProgressDialog>
#include <QPushButton>
#include <QStringList>
#include <QVBoxLayout>

// 종목 추가 다이얼로그의 검색, 다중 선택, AI 키워드 생성 흐름을 구현한다.
namespace { QStringList loadingLines() { return {"AI analyst is warming up the keyword radar…", "Scanning market context for sharper keywords…", "Turning ticker noise into usable search terms…", "Brewing a cleaner news signal for this symbol…", "Letting the keyword elves do one quick pass…"}; } }

AddSymbolDialog::AddSymbolDialog(SymbolListManager& manager, MarketCatalogService& marketService, WishlistWorkflowService& wishlistService, QWidget* parent)
    : QDialog(parent), manager_(manager), marketService_(marketService), wishlistService_(wishlistService) {
    setWindowTitle("Add Symbol"); setModal(true); resize(760, 620); setMinimumSize(680, 520);
    auto* root = new QVBoxLayout(this); root->setContentsMargins(22, 20, 22, 20); root->setSpacing(14);
    auto* eyebrow = new QLabel("ADD NEW SYMBOL", this); eyebrow->setObjectName("Eyebrow"); auto* title = new QLabel("Search enabled markets and add directly to your watchlist.", this); title->setObjectName("Heading"); title->setWordWrap(true); auto* subtitle = new QLabel("Results refresh while you type. Check multiple symbols, then add them together.", this); subtitle->setObjectName("PanelMeta"); subtitle->setWordWrap(true); root->addWidget(eyebrow); root->addWidget(title); root->addWidget(subtitle);
    auto* searchRow = new QHBoxLayout(); searchRow->setSpacing(10); marketBox_ = new QComboBox(this); marketBox_->addItem("All markets"); for (const auto& market : marketService_.getActiveMarkets()) marketBox_->addItem(qs(market).toUpper()); marketBox_->setFixedWidth(170); searchEdit_ = new QLineEdit(this); searchEdit_->setPlaceholderText("Search name or code (e.g. NVIDIA, 삼성전자)"); searchEdit_->setClearButtonEnabled(true); auto* searchBtn = new QPushButton("Search", this); searchBtn->setObjectName("Primary"); searchRow->addWidget(marketBox_); searchRow->addWidget(searchEdit_, 1); searchRow->addWidget(searchBtn); root->addLayout(searchRow);
    results_ = new QListWidget(this); results_->setSelectionMode(QAbstractItemView::NoSelection); root->addWidget(results_, 1);
    auto* footer = new QHBoxLayout(); selectionPill_ = new QLabel("0 selected", this); selectionPill_->setObjectName("StatPill"); hint_ = new QLabel("Type to search across enabled markets.", this); hint_->setObjectName("PanelMeta"); auto* cancelBtn = new QPushButton("Close", this); addBtn_ = new QPushButton("Add to Watchlist", this); addBtn_->setObjectName("Primary"); addBtn_->setEnabled(false); footer->addWidget(selectionPill_, 0); footer->addWidget(hint_, 1); footer->addWidget(cancelBtn); footer->addWidget(addBtn_); root->addLayout(footer);
    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject); connect(searchBtn, &QPushButton::clicked, this, &AddSymbolDialog::onSearch); connect(searchEdit_, &QLineEdit::returnPressed, this, &AddSymbolDialog::onSearch); connect(searchEdit_, &QLineEdit::textChanged, this, [this](const QString&) { onSearch(); }); connect(marketBox_, &QComboBox::currentIndexChanged, this, [this](int) { onSearch(); }); connect(results_, &QListWidget::itemChanged, this, [this](QListWidgetItem*) { onCheckedItemsChanged(); }); connect(results_, &QListWidget::itemClicked, this, &AddSymbolDialog::onItemActivated); connect(results_, &QListWidget::itemDoubleClicked, this, &AddSymbolDialog::onItemActivated); connect(addBtn_, &QPushButton::clicked, this, &AddSymbolDialog::onAdd);
}

void AddSymbolDialog::onSearch() {
    results_->clear(); addBtn_->setEnabled(false); selectionPill_->setText("0 selected");
    QString query = searchEdit_->text().trimmed(); if (query.isEmpty()) return void(hint_->setText("Type to search across enabled markets."));
    std::vector<std::string> active = marketService_.getActiveMarkets(); if (active.empty()) return void(hint_->setText("No active markets are available."));
    std::vector<std::string> target = marketBox_->currentIndex() == 0 ? active : std::vector<std::string>{active[marketBox_->currentIndex() - 1]};
    auto matches = manager_.searchMarketSymbols(target, query.toStdString()); if (matches.empty()) return void(hint_->setText("No matching symbols found."));
    for (const auto& match : matches) { auto* item = new QListWidgetItem(QString("%1\n%2  ·  %3").arg(qs(std::get<1>(match)), qs(std::get<0>(match)), qs(std::get<2>(match)).toUpper())); item->setFlags(item->flags() | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled); item->setCheckState(Qt::Unchecked); item->setData(Qt::UserRole, qs(std::get<0>(match))); item->setData(Qt::UserRole + 1, qs(std::get<1>(match))); item->setData(Qt::UserRole + 2, qs(std::get<2>(match))); results_->addItem(item); }
    syncCheckedItemVisuals(); hint_->setText(QString("%1 result(s) ready. Check the symbols you want to add.").arg(matches.size()));
}

int AddSymbolDialog::checkedItemCount() const { int count = 0; for (int i = 0; i < results_->count(); ++i) if (auto* item = results_->item(i); item && item->checkState() == Qt::Checked) ++count; return count; }

void AddSymbolDialog::onCheckedItemsChanged() {
    int count = checkedItemCount(); selectionPill_->setText(QString("%1 selected").arg(count)); addBtn_->setEnabled(count > 0); syncCheckedItemVisuals();
    hint_->setText(count <= 0 ? "Check one or more symbols to add them in one batch." : count == 1 ? "1 symbol selected. Click again to uncheck it." : QString("%1 symbols selected. Click a checked item again to remove it.").arg(count));
}

void AddSymbolDialog::onItemActivated(QListWidgetItem* item) { if (item) item->setCheckState(item->checkState() == Qt::Checked ? Qt::Unchecked : Qt::Checked); }

void AddSymbolDialog::syncCheckedItemVisuals() {
    for (int i = 0; i < results_->count(); ++i) {
        auto* item = results_->item(i); if (!item) continue; QFont font = item->font(); bool checked = item->checkState() == Qt::Checked;
        item->setBackground(QBrush(QColor(checked ? Theme::Color::AccentSoft : Theme::Color::Surface1))); item->setForeground(QBrush(QColor(Theme::Color::Ink))); font.setBold(checked); item->setFont(font);
    }
}

void AddSymbolDialog::onAdd() {
    QList<QListWidgetItem*> items; for (int i = 0; i < results_->count(); ++i) if (auto* item = results_->item(i); item && item->checkState() == Qt::Checked) items.push_back(item);
    if (items.isEmpty()) return;
    QProgressDialog progress(this); progress.setWindowTitle("Adding Symbols"); progress.setCancelButton(nullptr); progress.setMinimumDuration(0); progress.setRange(0, items.size()); progress.setValue(0); progress.setAutoClose(false); progress.setAutoReset(false);
    const QStringList lines = loadingLines(); int addedCount = 0, duplicateCount = 0; QStringList keywordWarnings;
    for (int i = 0; i < items.size(); ++i) {
        QListWidgetItem* item = items[i]; std::string code = item->data(Qt::UserRole).toString().toStdString(), name = item->data(Qt::UserRole + 1).toString().toStdString(), market = item->data(Qt::UserRole + 2).toString().toStdString();
        progress.setLabelText(lines[i % lines.size()] + "\n\n" + QString("Now tagging %1 (%2/%3)").arg(qs(name)).arg(i + 1).arg(items.size())); QApplication::processEvents();
        AddSymbolResult result = wishlistService_.addSymbolWithGeneratedKeywords(code, name, market); if (!result.keywordError.empty()) keywordWarnings << QString("%1: %2").arg(qs(name), QString::fromStdString(result.keywordError));
        if (result.added) ++addedCount; else if (result.duplicate) ++duplicateCount; progress.setValue(i + 1);
    }
    progress.close();
    if (!keywordWarnings.isEmpty()) ErrorHandler::showWarning(this, "Keyword extraction notes", "Some symbols were added without AI keywords:\n\n" + keywordWarnings.join("\n"));
    if (addedCount > 0) { emit symbolAdded(); ErrorHandler::showInfo(this, "Added", QString("%1 symbol(s) added.\n%2 duplicate(s) skipped.").arg(addedCount).arg(duplicateCount)); return accept(); }
    ErrorHandler::showInfo(this, "Nothing added", QString("No new symbols were added.\n%1 duplicate(s) were skipped.").arg(duplicateCount));
}
