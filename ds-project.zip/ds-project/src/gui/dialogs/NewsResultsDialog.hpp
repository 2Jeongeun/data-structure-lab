#pragma once

#include <QDialog>
#include <QStringList>

#include "../../service/news/ArticleExcerptService.hpp"
#include "../../service/news/NewsCollectionService.hpp"

class QComboBox;
class QLabel;
class QScrollArea;
class QVBoxLayout;
class QWidget;

// 검색어별 뉴스 수집 결과를 카드 목록으로 보여주는 다이얼로그다.
class NewsResultsDialog : public QDialog {
    Q_OBJECT
public:
    NewsResultsDialog(NewsCollectionService& newsService,
                      const QStringList& terms,
                      const QString& heading,
                      QWidget* parent = nullptr);

private:
    // 필요한 뉴스 데이터를 수집하거나 캐시에서 읽은 뒤 필터 목록을 구성한다.
    void load();
    // 현재 선택된 키워드 필터에 맞춰 뉴스 카드들을 다시 그린다.
    void renderArticles();

    NewsCollectionService& newsService_;
    ArticleExcerptService excerptService_;
    QStringList terms_;
    QString heading_;
    std::vector<NewsGroup> groups_;

    QLabel* titleLabel_ = nullptr;
    QLabel* metaLabel_ = nullptr;
    QComboBox* filterBox_ = nullptr;
    QScrollArea* scrollArea_ = nullptr;
    QWidget* container_ = nullptr;
    QVBoxLayout* contentLayout_ = nullptr;
};
