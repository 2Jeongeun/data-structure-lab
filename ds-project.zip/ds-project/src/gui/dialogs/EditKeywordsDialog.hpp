#pragma once

#include <QDialog>
#include <vector>

#include "../../service/wishlist/WishlistWorkflowService.hpp"
#include "../../symbolManage/Symbol.hpp"

class QLabel;
class QTextEdit;

// 한 종목에 연결된 뉴스 검색 키워드를 사용자가 직접 수정하는 다이얼로그다.
class EditKeywordsDialog : public QDialog {
    Q_OBJECT
public:
    EditKeywordsDialog(const Symbol& symbol,
                       WishlistWorkflowService& wishlistService,
                       QWidget* parent = nullptr);

signals:
    // 키워드가 실제로 변경되었을 때 위시리스트 화면 갱신을 요청한다.
    void keywordsUpdated();

private slots:
    // 저장 전 추가/삭제될 키워드를 미리 보여주고 확인 후 반영한다.
    void onReviewChanges();

private:
    // 쉼표, 줄바꿈, 세미콜론으로 입력된 키워드를 중복 없는 목록으로 정리한다.
    std::vector<std::string> parseKeywords() const;
    QString joinKeywords(const std::vector<std::string>& keywords) const;

    Symbol symbol_;
    WishlistWorkflowService& wishlistService_;
    QLabel* summaryLabel_ = nullptr;
    QTextEdit* editor_ = nullptr;
};
