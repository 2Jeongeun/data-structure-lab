#pragma once

#include <QString>
#include <string>

// std::string 기반 백엔드 값을 Qt 위젯에서 바로 쓰기 위한 짧은 변환 함수다.
inline QString qs(const std::string& s) { return QString::fromStdString(s); }
