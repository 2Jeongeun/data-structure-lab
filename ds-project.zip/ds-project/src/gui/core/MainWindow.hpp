#pragma once
#include <QMainWindow>
#include <unordered_map>
#include <vector>
#include <string>
#include "../../symbolManage/SymbolListManager.hpp"
#include "../../service/market/MarketCatalogService.hpp"
#include "../../service/news/NewsCollectionService.hpp"
#include "../../service/wishlist/WishlistWorkflowService.hpp"

class QComboBox;
class QLineEdit;
class QPushButton;
class QListWidget;
class QListWidgetItem;
class QLabel;
class QWidget;
class QFrame;
class QStackedWidget;
class QPropertyAnimation;
class WishlistPage;

// 앱의 메인 창이다.
// 뉴스 검색 화면과 위시리스트 화면을 QStackedWidget으로 전환하며 전체 GUI 흐름을 제어한다.
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(SymbolListManager& manager,
               MarketCatalogService& marketService,
               NewsCollectionService& newsService,
               WishlistWorkflowService& wishlistService,
               QWidget* parent = nullptr);

private slots:
    // 검색 모드에 따라 키워드 직접 검색 또는 위시리스트 종목 검색을 수행한다.
    void onSearch();
    // 검색 결과 항목을 클릭하면 관련 뉴스 다이얼로그를 연다.
    void onResultClicked(QListWidgetItem* item);
    void toggleSidebar();
    void navTo(int index);

private:
    // 뉴스 검색 페이지 위젯들을 생성한다.
    QWidget* buildNewsPage();
    // 입력한 문자열과 가장 잘 맞는 위시리스트 종목 목록을 캐시 기반으로 필터링한다.
    std::vector<Symbol> filteredWishlistSymbols(const QString& query);
    void clearWishlistSearchCache();
    QStringList termsForSymbol(const std::string& name);

    SymbolListManager& manager;
    MarketCatalogService& marketService;
    NewsCollectionService& newsService;
    WishlistWorkflowService& wishlistService;

    QFrame* sidebar = nullptr;
    QPropertyAnimation* sidebarAnim = nullptr;
    bool sidebarOpen = false;
    QStackedWidget* stack = nullptr;
    QPushButton* navNews = nullptr;
    QPushButton* navWishlist = nullptr;
    WishlistPage* wishlistPage = nullptr;

    QComboBox* modeBox = nullptr;
    QLineEdit* searchEdit = nullptr;
    QPushButton* searchBtn = nullptr;
    QListWidget* results = nullptr;
    QLabel* statusLabel = nullptr;

    std::vector<Symbol> cachedWishlistSymbols_;
    std::unordered_map<std::string, std::vector<Symbol>> wishlistSearchCache_;
};
