#include <QApplication>

#include "../../app/GuiAppContext.hpp"
#include "../shared/Theme.hpp"
#include "MainWindow.hpp"

int main(int argc, char** argv) {
    QApplication app(argc, argv);
    app.setStyleSheet(Theme::styleSheet());

    // 앱 전체에서 공유할 DB/서비스 객체를 먼저 준비한다.
    GuiAppContext appContext;
    if (!appContext.initialize()) {
        return 1;
    }

    // 메인 화면에는 초기화가 끝난 서비스 참조만 전달한다.
    MainWindow window(
        appContext.manager(),
        appContext.marketService(),
        appContext.newsService(),
        appContext.wishlistService());
    window.show();
    return app.exec();
}
