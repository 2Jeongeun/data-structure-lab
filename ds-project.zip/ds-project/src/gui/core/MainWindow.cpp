#include "MainWindow.hpp"
#include "../dialogs/NewsResultsDialog.hpp"
#include "../shared/QtString.hpp"
#include "../shared/Theme.hpp"
#include "../widgets/WishlistPage.hpp"
#include "../../common/StringUtil.hpp"
#include <QApplication>
#include <QButtonGroup>
#include <QComboBox>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QPropertyAnimation>
#include <QPushButton>
#include <QStackedWidget>
#include <QStatusBar>
#include <QVBoxLayout>
namespace { constexpr int SIDEBAR_WIDTH = 230; }

MainWindow::MainWindow(SymbolListManager& managerRef, MarketCatalogService& marketServiceRef, NewsCollectionService& newsServiceRef, WishlistWorkflowService& wishlistServiceRef, QWidget* parent)
    : QMainWindow(parent), manager(managerRef), marketService(marketServiceRef), newsService(newsServiceRef), wishlistService(wishlistServiceRef) {
    setWindowTitle("Wishlist News"); resize(1200, 760); setMinimumSize(980, 600);
    auto* central = new QWidget(this); auto* outer = new QVBoxLayout(central); outer->setContentsMargins(0, 0, 0, 0); outer->setSpacing(0);
    auto* topBar = new QFrame(this); topBar->setObjectName("TopBar"); topBar->setFixedHeight(60); auto* topLay = new QHBoxLayout(topBar); topLay->setContentsMargins(12, 0, 24, 0); topLay->setSpacing(10);
    auto* menuBtn = new QPushButton("☰", topBar); menuBtn->setObjectName("Menu"); menuBtn->setCursor(Qt::PointingHandCursor); topLay->addWidget(menuBtn);
    auto* titleBox = new QVBoxLayout(); titleBox->setSpacing(2); auto* appTitle = new QLabel("Market Pulse Desk", topBar); appTitle->setObjectName("AppTitle"); auto* appSubtitle = new QLabel("Watchlist-driven symbol discovery and news review", topBar); appSubtitle->setObjectName("AppSubtitle"); titleBox->addWidget(appTitle); titleBox->addWidget(appSubtitle); topLay->addLayout(titleBox); topLay->addStretch(1); outer->addWidget(topBar);
    auto* body = new QWidget(this); auto* bodyLay = new QHBoxLayout(body); bodyLay->setContentsMargins(0, 0, 0, 0); bodyLay->setSpacing(0);
    sidebar = new QFrame(body); sidebar->setObjectName("Sidebar"); sidebar->setMinimumWidth(0); sidebar->setMaximumWidth(0);
    auto* sideLay = new QVBoxLayout(sidebar); sideLay->setContentsMargins(12, 18, 12, 18); sideLay->setSpacing(6); auto* navLabel = new QLabel("MENU", sidebar); navLabel->setObjectName("NavSectionLabel"); sideLay->addWidget(navLabel); sideLay->addSpacing(6);
    navNews = new QPushButton("🔍   뉴스 검색", sidebar); navWishlist = new QPushButton("★   위시리스트 관리", sidebar);
    for (auto* btn : {navNews, navWishlist}) { btn->setObjectName("NavItem"); btn->setCheckable(true); btn->setCursor(Qt::PointingHandCursor); sideLay->addWidget(btn); }
    auto* navGroup = new QButtonGroup(this); navGroup->setExclusive(true); navGroup->addButton(navNews, 0); navGroup->addButton(navWishlist, 1); sideLay->addStretch(1);
    stack = new QStackedWidget(body); stack->addWidget(buildNewsPage()); wishlistPage = new WishlistPage(manager, marketService, wishlistService); stack->addWidget(wishlistPage);
    bodyLay->addWidget(sidebar); bodyLay->addWidget(stack, 1); outer->addWidget(body, 1); setCentralWidget(central);
    statusLabel = new QLabel("Ready", this); statusBar()->addWidget(statusLabel); sidebarAnim = new QPropertyAnimation(sidebar, "maximumWidth", this); sidebarAnim->setDuration(190); sidebarAnim->setEasingCurve(QEasingCurve::InOutCubic);
    connect(menuBtn, &QPushButton::clicked, this, &MainWindow::toggleSidebar); connect(navNews, &QPushButton::clicked, this, [this] { navTo(0); }); connect(navWishlist, &QPushButton::clicked, this, [this] { navTo(1); });
    navNews->setChecked(true); stack->setCurrentIndex(0);
}

QWidget* MainWindow::buildNewsPage() {
    auto* page = new QWidget(); auto* lay = new QVBoxLayout(page); lay->setContentsMargins(24, 18, 24, 16); lay->setSpacing(18);
    // 검색창, 결과 목록만 있는 단순한 뉴스 진입 페이지를 구성한다.
    auto* searchCard = new QFrame(page); searchCard->setObjectName("SectionCard"); auto* cardLay = new QVBoxLayout(searchCard); cardLay->setContentsMargins(18, 16, 18, 16); cardLay->setSpacing(10);
    auto* searchTitle = new QLabel("Search", searchCard); searchTitle->setObjectName("PanelTitle"); cardLay->addWidget(searchTitle);
    auto* searchRow = new QHBoxLayout(); searchRow->setSpacing(10); modeBox = new QComboBox(page); modeBox->addItems({"Symbol", "Keyword"}); modeBox->setFixedWidth(120); searchEdit = new QLineEdit(page); searchEdit->setPlaceholderText("Search…  (e.g. NVIDIA, 삼성전자, 반도체)"); searchEdit->setClearButtonEnabled(true); searchBtn = new QPushButton("Search", page); searchBtn->setObjectName("Primary"); searchBtn->setMinimumHeight(38); searchRow->addWidget(modeBox); searchRow->addWidget(searchEdit, 1); searchRow->addWidget(searchBtn); cardLay->addLayout(searchRow); lay->addWidget(searchCard);
    auto* leftPanel = new QFrame(page); leftPanel->setObjectName("ResultsPanel"); auto* left = new QVBoxLayout(leftPanel); left->setContentsMargins(18, 18, 18, 18); left->setSpacing(8);
    auto* resTitle = new QLabel("Search Results", leftPanel); resTitle->setObjectName("PanelTitle"); auto* resMeta = new QLabel("Choose one result to load a dedicated news feed.", leftPanel); resMeta->setObjectName("PanelMeta"); results = new QListWidget(leftPanel); results->setMaximumHeight(180); left->addWidget(resTitle); left->addWidget(resMeta); left->addWidget(results); lay->addWidget(leftPanel); lay->addStretch(1);
    connect(searchBtn, &QPushButton::clicked, this, &MainWindow::onSearch); connect(searchEdit, &QLineEdit::returnPressed, this, &MainWindow::onSearch); connect(searchEdit, &QLineEdit::textChanged, this, [this](const QString&) { onSearch(); }); connect(modeBox, &QComboBox::currentIndexChanged, this, [this](int) { onSearch(); }); connect(results, &QListWidget::itemClicked, this, &MainWindow::onResultClicked);
    return page;
}

void MainWindow::toggleSidebar() { int target = sidebarOpen ? 0 : SIDEBAR_WIDTH; sidebarOpen = !sidebarOpen; sidebarAnim->stop(); sidebarAnim->setStartValue(sidebar->maximumWidth()); sidebarAnim->setEndValue(target); sidebarAnim->start(); }
void MainWindow::navTo(int index) { stack->setCurrentIndex(index); navNews->setChecked(index == 0); navWishlist->setChecked(index == 1); if (index == 1 && wishlistPage) wishlistPage->refreshTable(); clearWishlistSearchCache(); }
void MainWindow::clearWishlistSearchCache() { cachedWishlistSymbols_.clear(); wishlistSearchCache_.clear(); }

std::vector<Symbol> MainWindow::filteredWishlistSymbols(const QString& query) {
    std::vector<Symbol> matches;
    std::string needle = common::lower(query.trimmed().toStdString());

    if (cachedWishlistSymbols_.empty()) {
        cachedWishlistSymbols_ = manager.getWishlist();
    }

    if (auto cached = wishlistSearchCache_.find(needle);
        cached != wishlistSearchCache_.end()) {
        return cached->second;
    }

    const std::vector<Symbol>* source = &cachedWishlistSymbols_;
    std::string bestPrefix;

    // 이전 검색 결과 중 현재 입력과 가장 많이 겹치는 접두어를 찾아
    // 이미 좁혀진 목록 안에서 다시 필터링한다.
    for (const auto& [prefix, values] : wishlistSearchCache_) {
        if (needle.rfind(prefix, 0) == 0 && prefix.size() > bestPrefix.size()) {
            bestPrefix = prefix;
            source = &values;
        }
    }

    for (const auto& symbol : *source) {
        if (common::lower(symbol.name).find(needle) != std::string::npos ||
            common::lower(symbol.code).find(needle) != std::string::npos) {
            matches.push_back(symbol);
        }
    }

    return wishlistSearchCache_[needle] = matches;
}

QStringList MainWindow::termsForSymbol(const std::string& name) {
    QStringList out;
    int symbolId = wishlistService.findSymbolIdByName(name);

    if (symbolId >= 0) {
        for (const auto& term : wishlistService.getSearchTerms(symbolId)) {
            out << qs(term);
        }
    }

    // 키워드가 비어 있어도 최소한 종목명으로는 뉴스 검색이 가능하게 한다.
    if (out.isEmpty()) {
        out << qs(name);
    }
    return out;
}

void MainWindow::onSearch() {
    QString query = searchEdit->text().trimmed(); results->clear();
    if (query.isEmpty()) return void(statusLabel->setText("Type to search symbols or keywords."));
    if (modeBox->currentIndex() == 1) { auto* item = new QListWidgetItem("# " + query); item->setData(Qt::UserRole, "keyword"); item->setData(Qt::UserRole + 1, query); results->addItem(item); return void(statusLabel->setText("Keyword ready. Click the result to load news.")); }
    auto matches = filteredWishlistSymbols(query); if (matches.empty()) return void(statusLabel->setText("No matching symbols in your watchlist."));
    for (const auto& symbol : matches) { auto* item = new QListWidgetItem(QString("%1\n%2 · %3").arg(qs(symbol.name), qs(symbol.code), qs(symbol.market).toUpper())); item->setData(Qt::UserRole, "symbol"); item->setData(Qt::UserRole + 1, qs(symbol.code)); item->setData(Qt::UserRole + 2, qs(symbol.name)); item->setData(Qt::UserRole + 3, qs(symbol.market)); results->addItem(item); }
    statusLabel->setText(QString("%1 symbol(s) found · click one to load news").arg(matches.size()));
}

void MainWindow::onResultClicked(QListWidgetItem* item) {
    if (!item) return;
    if (item->data(Qt::UserRole).toString() == "keyword") {
        // 키워드 모드는 사용자가 입력한 문장 자체를 바로 뉴스 검색어로 사용한다.
        QString term = item->data(Qt::UserRole + 1).toString(); auto* dialog = new NewsResultsDialog(newsService, {term}, "# " + term, this); dialog->setAttribute(Qt::WA_DeleteOnClose); dialog->show(); statusLabel->setText("Opened keyword news viewer."); return;
    }
    // 심볼 모드는 종목명 + 연결 키워드 묶음으로 관련 뉴스를 더 넓게 찾는다.
    std::string name = item->data(Qt::UserRole + 2).toString().toStdString(); auto* dialog = new NewsResultsDialog(newsService, termsForSymbol(name), qs(name), this); dialog->setAttribute(Qt::WA_DeleteOnClose); dialog->show(); statusLabel->setText(QString("Opened news viewer for %1.").arg(qs(name)));
}
