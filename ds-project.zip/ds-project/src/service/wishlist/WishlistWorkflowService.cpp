#include "WishlistWorkflowService.hpp"

#include <algorithm>

WishlistWorkflowService::WishlistWorkflowService(
    SymbolListManager& manager,
    KeywordExtractionService& keywordService,
    NewsCollectionService& newsService)
    : manager_(manager),
      keywordService_(keywordService),
      newsService_(newsService) {}

int WishlistWorkflowService::findSymbolIdByName(const std::string& name) const {
    for (const auto& s : manager_.getWishlist()) {
        if (s.name == name) {
            return s.id;
        }
    }
    return -1;
}

std::vector<std::string> WishlistWorkflowService::getSearchTerms(int symbolId) const {
    return manager_.getSearchTerms(symbolId);
}

std::vector<std::string> WishlistWorkflowService::ensureSearchTerms(
    const std::string& code,
    const std::string& name,
    const std::string& market) {
    // 이미 위시리스트에 있는 종목이면 기존 검색어를 그대로 재사용한다.
    if (auto id = findSymbolIdByName(name); id >= 0) {
        return manager_.getSearchTerms(id);
    }

    auto result = addSymbolWithGeneratedKeywords(code, name, market);

    // 저장 직후 DB에서 다시 읽는 것이 가장 정확하지만,
    // 실패한 경우에도 최소한 종목명 + 생성 키워드는 반환해 뉴스 검색을 이어갈 수 있게 한다.
    std::vector<std::string> fallback{name};
    fallback.insert(fallback.end(), result.keywords.begin(), result.keywords.end());

    if (auto id = findSymbolIdByName(name); id >= 0) {
        return manager_.getSearchTerms(id);
    }
    return fallback;
}

AddSymbolResult WishlistWorkflowService::addSymbolWithGeneratedKeywords(
    const std::string& code,
    const std::string& name,
    const std::string& market) {
    AddSymbolResult result;

    try {
        // AI/룰 기반 키워드 생성은 실패할 수 있으므로 예외를 분리해 둔다.
        result.keywords = keywordService_.extractKeywords(name, market);
    } catch (const std::exception& e) {
        result.keywordError = e.what();
    }

    result.added = manager_.addSymbol(Symbol(name, code, market, result.keywords));
    result.duplicate = !result.added && findSymbolIdByName(name) >= 0;
    return result;
}

UpdateKeywordsResult WishlistWorkflowService::updateSymbolKeywords(
    int symbolId,
    const std::vector<std::string>& keywords) {
    UpdateKeywordsResult result;
    std::vector<std::string> previous;

    for (const auto& s : manager_.getWishlist()) {
        if (s.id == symbolId) {
            previous = s.keywords;
            break;
        }
    }

    // 변경 전/후를 비교해서 UI에 어떤 키워드가 추가/삭제됐는지 알려준다.
    for (const auto& keyword : keywords) {
        if (std::find(previous.begin(), previous.end(), keyword) == previous.end()) {
            result.addedKeywords.push_back(keyword);
        }
    }
    for (const auto& keyword : previous) {
        if (std::find(keywords.begin(), keywords.end(), keyword) == keywords.end()) {
            result.removedKeywords.push_back(keyword);
        }
    }

    if (result.addedKeywords.empty() && result.removedKeywords.empty()) {
        return result;
    }

    result.orphanedTerms = manager_.updateSymbolKeywords(symbolId, keywords);
    result.purgedTerms = newsService_.purgeTerms(result.orphanedTerms);
    result.updated = true;
    return result;
}

RemoveSymbolResult WishlistWorkflowService::removeSymbolAndPurgeNews(int symbolId) {
    RemoveSymbolResult result;

    // 종목 삭제 후 더 이상 쓰이지 않는 검색어 뉴스 캐시까지 함께 정리한다.
    result.orphanedTerms = manager_.removeSymbol(symbolId);
    result.purgedTerms = newsService_.purgeTerms(result.orphanedTerms);
    return result;
}
