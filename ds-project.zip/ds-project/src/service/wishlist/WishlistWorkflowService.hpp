#pragma once
#include <string>
#include <vector>
#include "../../symbolManage/SymbolListManager.hpp"
#include "../ai/KeywordExtractionService.hpp"
#include "../news/NewsCollectionService.hpp"

// 종목 추가 흐름의 결과를 UI가 메시지로 보여주기 쉽게 묶은 구조체다.
struct AddSymbolResult {
    bool added = false;
    bool duplicate = false;
    std::vector<std::string> keywords;
    std::string keywordError;
};

// 종목 삭제 후 함께 정리된 뉴스 캐시 정보를 담는다.
struct RemoveSymbolResult {
    int purgedTerms = 0;
    std::vector<std::string> orphanedTerms;
};

// 키워드 수정 전후 차이와 고아 뉴스 캐시 정리 결과를 담는다.
struct UpdateKeywordsResult {
    bool updated = false;
    int purgedTerms = 0;
    std::vector<std::string> addedKeywords;
    std::vector<std::string> removedKeywords;
    std::vector<std::string> orphanedTerms;
};

// 종목 추가/수정/삭제를 하나의 업무 흐름으로 묶는 서비스 계층이다.
// SymbolListManager, AI 키워드 생성, 뉴스 캐시 정리를 조합해 GUI 코드의 책임을 줄인다.
class WishlistWorkflowService {
    SymbolListManager& manager_;
    KeywordExtractionService& keywordService_;
    NewsCollectionService& newsService_;

public:
    WishlistWorkflowService(SymbolListManager& manager,
                            KeywordExtractionService& keywordService,
                            NewsCollectionService& newsService);
    int findSymbolIdByName(const std::string& name) const;
    std::vector<std::string> getSearchTerms(int symbolId) const;

    // 저장된 키워드가 있으면 재사용하고, 없으면 최소 검색어를 보장한다.
    std::vector<std::string> ensureSearchTerms(const std::string& code,
                                               const std::string& name,
                                               const std::string& market);
    // 종목 저장과 AI 키워드 생성을 하나의 버튼 동작에서 처리한다.
    AddSymbolResult addSymbolWithGeneratedKeywords(const std::string& code,
                                                   const std::string& name,
                                                   const std::string& market);
    // 키워드 변경 후 더 이상 참조되지 않는 뉴스 캐시도 정리한다.
    UpdateKeywordsResult updateSymbolKeywords(int symbolId,
                                              const std::vector<std::string>& keywords);
    RemoveSymbolResult removeSymbolAndPurgeNews(int symbolId);
};
