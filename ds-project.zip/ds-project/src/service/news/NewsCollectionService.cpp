#include "NewsCollectionService.hpp"

#include "../../naverNewsHandler/NaverNewsClient.hpp"

NewsCollectionService::NewsCollectionService(NewsDatabase& newsDatabase)
    : newsDatabase_(newsDatabase) {}

NewsFetchSummary NewsCollectionService::collectTerms(
    const std::vector<std::string>& terms,
    const std::string& sort) {
    NewsFetchSummary summary;
    NaverNewsClient client;

    for (const auto& term : terms) {
        // 최근에 이미 가져온 검색어는 API를 다시 부르지 않고 캐시를 재사용한다.
        if (newsDatabase_.isFresh(term)) {
            ++summary.reusedTerms;
            continue;
        }

        // 오래된 검색어만 새로 수집해서 DB에 저장한다.
        if (newsDatabase_.saveNewsForKeyword(term, client.search(term, 5, sort))) {
            ++summary.fetchedTerms;
        }
    }

    // 최종적으로는 각 검색어별 기사 묶음을 다시 읽어서 화면에서 바로 쓸 수 있게 한다.
    for (const auto& group : loadGroups(terms)) {
        summary.articleCount += static_cast<int>(group.articles.size());
    }

    return summary;
}

std::vector<NewsGroup> NewsCollectionService::loadGroups(
    const std::vector<std::string>& terms) const {
    std::vector<NewsGroup> out;

    for (const auto& term : terms) {
        auto articles = newsDatabase_.getNewsForKeyword(term);
        if (!articles.empty()) {
            // 검색어 하나당 기사 리스트 하나를 만들어 다이얼로그에서 그룹 단위로 보여준다.
            out.push_back({term, std::move(articles)});
        }
    }

    return out;
}

int NewsCollectionService::purgeTerms(const std::vector<std::string>& terms) {
    int purged = 0;
    for (const auto& term : terms) {
        // 더 이상 어떤 종목에서도 쓰지 않는 검색어 뉴스만 정리한다.
        if (newsDatabase_.deleteNewsForKeyword(term)) {
            ++purged;
        }
    }
    return purged;
}
