#pragma once

#include <string>
#include <vector>

#include "../../dataManage/news/NewsDatabase.hpp"

// 하나의 검색어와 그 검색어로 수집된 뉴스 기사 목록을 함께 전달한다.
struct NewsGroup {
    std::string term;
    std::vector<NaverNewsArticle> articles;
};

// 뉴스 수집 과정에서 새로 가져온 검색어와 캐시를 재사용한 검색어 수를 기록한다.
struct NewsFetchSummary {
    int fetchedTerms = 0;
    int reusedTerms = 0;
    int articleCount = 0;
};

// 검색어 목록을 기준으로 뉴스 API 호출, 캐시 재사용, DB 조회를 담당하는 서비스다.
class NewsCollectionService {
    NewsDatabase& newsDatabase_;

public:
    explicit NewsCollectionService(NewsDatabase& newsDatabase);

    // 오래된 검색어만 API로 다시 가져오고, 신선한 데이터는 DB 캐시를 재사용한다.
    NewsFetchSummary collectTerms(const std::vector<std::string>& terms,
                                  const std::string& sort = "sim");
    // 화면 표시를 위해 검색어별 기사 묶음을 DB에서 다시 읽는다.
    std::vector<NewsGroup> loadGroups(const std::vector<std::string>& terms) const;
    // 더 이상 쓰이지 않는 검색어의 뉴스 캐시를 삭제한다.
    int purgeTerms(const std::vector<std::string>& terms);
};
