#include "ArticleExcerptService.hpp"

#include "../../common/StringUtil.hpp"
#include "../../errorHandler/ErrorHandler.hpp"

#include <curl/curl.h>

#include <algorithm>
#include <array>
#include <cctype>
#include <string>
#include <vector>

namespace {

size_t writeCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    auto* buffer = static_cast<std::string*>(userp);
    buffer->append(static_cast<char*>(contents), size * nmemb);
    return size * nmemb;
}

void replaceAll(std::string& text, const std::string& from, const std::string& to) {
    for (size_t pos = 0; (pos = text.find(from, pos)) != std::string::npos;) {
        text.replace(pos, from.size(), to);
        pos += to.size();
    }
}

std::string lower(std::string text) {
    std::transform(text.begin(), text.end(), text.begin(), [](unsigned char ch) {
        return static_cast<char>(std::tolower(ch));
    });
    return text;
}

void removeTagBlock(std::string& html, const std::string& openTag, const std::string& closeTag) {
    std::string lowered = lower(html);
    std::string openNeedle = "<" + openTag;
    std::string closeNeedle = "</" + closeTag + ">";

    for (size_t start = 0; (start = lowered.find(openNeedle, start)) != std::string::npos;) {
        size_t end = lowered.find(closeNeedle, start);
        if (end == std::string::npos) {
            html.erase(start);
            break;
        }
        end += closeNeedle.size();
        html.erase(start, end - start);
        lowered.erase(start, end - start);
    }
}

void removeHtmlComments(std::string& html) {
    for (size_t start = 0; (start = html.find("<!--", start)) != std::string::npos;) {
        size_t end = html.find("-->", start);
        if (end == std::string::npos) {
            html.erase(start);
            break;
        }
        html.erase(start, end + 3 - start);
    }
}

bool isUtf8Continuation(unsigned char byte) {
    return (byte & 0xC0) == 0x80;
}

std::string sanitizeUtf8(const std::string& input) {
    std::string out;
    out.reserve(input.size());

    for (size_t i = 0; i < input.size();) {
        unsigned char c = static_cast<unsigned char>(input[i]);

        if (c < 0x80) {
            out.push_back(static_cast<char>(c));
            ++i;
            continue;
        }

        int needed = 0;
        if ((c & 0xE0) == 0xC0) needed = 1;
        else if ((c & 0xF0) == 0xE0) needed = 2;
        else if ((c & 0xF8) == 0xF0) needed = 3;
        else {
            ++i;
            continue;
        }

        if (i + needed >= input.size()) {
            break;
        }

        bool valid = true;
        for (int j = 1; j <= needed; ++j) {
            if (!isUtf8Continuation(static_cast<unsigned char>(input[i + j]))) {
                valid = false;
                break;
            }
        }

        if (!valid) {
            ++i;
            continue;
        }

        out.append(input, i, needed + 1);
        i += needed + 1;
    }

    return out;
}

std::string decodeEntities(std::string text) {
    for (const auto& [from, to] : std::array<std::pair<const char*, const char*>, 12>{{
             {"&nbsp;", " "},
             {"&amp;", "&"},
             {"&quot;", "\""},
             {"&#34;", "\""},
             {"&#39;", "'"},
             {"&apos;", "'"},
             {"&lt;", "<"},
             {"&gt;", ">"},
             {"&ldquo;", "\""},
             {"&rdquo;", "\""},
             {"&lsquo;", "'"},
             {"&rsquo;", "'"},
         }}) {
        replaceAll(text, from, to);
    }
    return text;
}

std::string stripTags(std::string html) {
    html = decodeEntities(std::move(html));

    std::string out;
    out.reserve(html.size());

    bool inTag = false;
    bool lastWasSpace = false;
    for (unsigned char ch : html) {
        if (ch == '<') {
            inTag = true;
            continue;
        }
        if (ch == '>') {
            inTag = false;
            if (!lastWasSpace) {
                out.push_back(' ');
                lastWasSpace = true;
            }
            continue;
        }
        if (inTag) {
            continue;
        }

        if (std::isspace(ch)) {
            if (!lastWasSpace) {
                out.push_back(' ');
                lastWasSpace = true;
            }
            continue;
        }

        out.push_back(static_cast<char>(ch));
        lastWasSpace = false;
    }

    return common::trim(sanitizeUtf8(out));
}

bool looksLikeBoilerplate(const std::string& text) {
    if (text.size() < 40) {
        return true;
    }

    const std::string lowered = lower(text);
    for (const auto& needle : std::array<const char*, 15>{
             "copyright",
             "all rights reserved",
             "무단 전재",
             "재배포 금지",
             "기사제보",
             "메일",
             "기자",
             "페이스북",
             "트위터",
             "url 복사",
             "글씨 크기",
             "function(",
             "var ",
             "document.",
             "window.",
         }) {
        if (lowered.find(needle) != std::string::npos) {
            return true;
        }
    }

    return false;
}

std::string focusRegion(const std::string& html) {
    const std::string lowered = lower(html);
    for (const auto& marker : std::array<const char*, 10>{
             "articlebody",
             "article_body",
             "article-body",
             "newsct_article",
             "view_cont",
             "article_txt",
             "article_view",
             "news_view",
             "article-content",
             "post-content",
         }) {
        size_t pos = lowered.find(marker);
        if (pos == std::string::npos) {
            continue;
        }

        size_t begin = pos > 4000 ? pos - 4000 : 0;
        size_t length = std::min<size_t>(70000, html.size() - begin);
        return html.substr(begin, length);
    }
    return html;
}

std::vector<std::string> extractBlocks(const std::string& html,
                                       const std::string& tagName,
                                       size_t minLength,
                                       size_t maxCount) {
    std::vector<std::string> out;
    const std::string lowered = lower(html);
    const std::string openNeedle = "<" + tagName;
    const std::string closeNeedle = "</" + tagName + ">";

    for (size_t pos = 0;
         (pos = lowered.find(openNeedle, pos)) != std::string::npos && out.size() < maxCount;) {
        size_t gt = lowered.find('>', pos);
        size_t end = gt == std::string::npos ? std::string::npos : lowered.find(closeNeedle, gt);
        if (gt == std::string::npos || end == std::string::npos) {
            break;
        }

        std::string text = stripTags(html.substr(gt + 1, end - gt - 1));
        if (text.size() >= minLength && !looksLikeBoilerplate(text)) {
            out.push_back(std::move(text));
        }
        pos = end + closeNeedle.size();
    }

    return out;
}

std::string joinExcerpt(const std::vector<std::string>& blocks) {
    std::string out;
    const int count = std::min<int>(5, static_cast<int>(blocks.size()));
    for (int i = 0; i < count; ++i) {
        out += blocks[i];
        if (i + 1 < count) {
            out += "\n\n";
        }
    }
    return common::trim(out);
}

std::string extractExcerpt(const std::string& rawHtml) {
    std::string html = focusRegion(rawHtml);
    removeHtmlComments(html);
    removeTagBlock(html, "script", "script");
    removeTagBlock(html, "style", "style");
    removeTagBlock(html, "noscript", "noscript");
    removeTagBlock(html, "svg", "svg");
    removeTagBlock(html, "iframe", "iframe");

    auto paragraphs = extractBlocks(html, "p", 50, 8);
    if (!paragraphs.empty()) {
        return joinExcerpt(paragraphs);
    }

    auto divs = extractBlocks(html, "div", 100, 8);
    return joinExcerpt(divs);
}

}  // namespace

std::string ArticleExcerptService::fetchExcerpt(const std::string& url) {
    if (url.empty()) {
        return "";
    }

    if (auto it = cache_.find(url); it != cache_.end()) {
        return it->second;
    }

    CURL* curl = curl_easy_init();
    if (!curl) {
        return "";
    }

    std::string html;
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &html);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 12L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0");

    CURLcode result = curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    if (result != CURLE_OK) {
        return cache_[url] = "";
    }

    try {
        return cache_[url] = extractExcerpt(html);
    } catch (const std::exception& e) {
        ErrorHandler::logError(
            "Article excerpt extraction failed: " + std::string(e.what()));
        return cache_[url] = "";
    }
}
