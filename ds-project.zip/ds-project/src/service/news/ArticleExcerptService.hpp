#pragma once

#include <string>
#include <unordered_map>

// 뉴스 카드에서 원문 링크를 눌렀을 때 기사 본문 일부를 가져오는 보조 서비스다.
// 같은 URL을 반복해서 열 때 불필요한 네트워크 호출을 줄이기 위해 메모리 캐시를 사용한다.
class ArticleExcerptService {
public:
    std::string fetchExcerpt(const std::string& url);

private:
    // key: 기사 URL, value: 정제된 본문 일부
    std::unordered_map<std::string, std::string> cache_;
};
