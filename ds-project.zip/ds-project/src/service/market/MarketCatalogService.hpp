#pragma once

#include <string>
#include <vector>

#include "../../dataManage/wishlist/WishlistDatabase.hpp"

// UI에 표시할 시장 설정 정보다.
struct MarketInfo {
    std::string name;
    bool isActive = false;
    std::string lastUpdated;
};

// 시장 DB 갱신 작업에서 성공/실패한 시장명을 분리해 보고한다.
struct MarketSyncResult {
    std::vector<std::string> syncedMarkets;
    std::vector<std::string> failedMarkets;
};

// 활성 시장 목록, 마지막 갱신 시각, 시장 데이터 동기화를 관리하는 서비스다.
class MarketCatalogService {
    WishlistDatabase& database_;

public:
    explicit MarketCatalogService(WishlistDatabase& database);

    // 위시리스트 DB에 저장된 시장 설정을 읽는다.
    std::vector<MarketInfo> getMarkets() const;
    std::vector<std::string> getActiveMarkets() const;
    std::vector<std::string> getMarketsNeedingAutoUpdate() const;

    // 시장 활성화 여부와 마지막 갱신 시각을 업데이트한다.
    bool toggleMarket(const std::string& marketName);
    bool updateLastUpdated(const std::string& marketName);

    // scripts/update_market.py를 호출해 개별 또는 활성 시장 DB를 갱신한다.
    MarketSyncResult syncMarket(const std::string& marketName);
    MarketSyncResult syncActiveMarkets();
    MarketSyncResult autoUpdateStaleMarkets();

private:
    MarketSyncResult syncMarkets(const std::vector<std::string>& marketNames);
};
