#include "MarketCatalogService.hpp"

#include "../../common/SqliteUtils.hpp"

#include <cstdlib>

namespace {

bool runSyncScript(const std::string& marketName) {
    return std::system(("python3 scripts/update_market.py " + marketName).c_str()) == 0;
}

std::vector<std::string> queryNames(sqlite3* db, const char* sql) {
    std::vector<std::string> out;
    if (!db) {
        return out;
    }

    try {
        sqlite_utils::Statement stmt(db, sql);
        while (sqlite3_step(stmt.stmt) == SQLITE_ROW) {
            auto value = sqlite_utils::columnText(stmt.stmt, 0);
            if (!value.empty()) {
                out.push_back(value);
            }
        }
    } catch (...) {
    }

    return out;
}

bool runUpdate(sqlite3* db, const char* sql, const std::string& value) {
    if (!db) {
        return false;
    }

    try {
        sqlite_utils::Statement stmt(db, sql);
        sqlite3_bind_text(stmt.stmt, 1, value.c_str(), -1, SQLITE_TRANSIENT);
        return sqlite3_step(stmt.stmt) == SQLITE_DONE;
    } catch (...) {
        return false;
    }
}

}  // namespace

MarketCatalogService::MarketCatalogService(WishlistDatabase& database)
    : database_(database) {}

std::vector<MarketInfo> MarketCatalogService::getMarkets() const {
    std::vector<MarketInfo> out;
    auto* db = database_.getHandle();
    if (!db) {
        return out;
    }

    try {
        sqlite_utils::Statement stmt(
            db,
            "SELECT market_name, is_active, last_updated "
            "FROM market_config ORDER BY market_name ASC;");
        while (sqlite3_step(stmt.stmt) == SQLITE_ROW) {
            out.push_back({sqlite_utils::columnText(stmt.stmt, 0),
                           sqlite3_column_int(stmt.stmt, 1) == 1,
                           sqlite_utils::columnText(stmt.stmt, 2)});
        }
    } catch (...) {
    }

    return out;
}

std::vector<std::string> MarketCatalogService::getActiveMarkets() const {
    std::vector<std::string> out;
    for (const auto& market : getMarkets()) {
        if (market.isActive) {
            out.push_back(market.name);
        }
    }
    return out;
}

std::vector<std::string> MarketCatalogService::getMarketsNeedingAutoUpdate() const {
    return queryNames(
        database_.getHandle(),
        "SELECT market_name FROM market_config "
        "WHERE is_active = 1 "
        "AND (last_updated IS NULL OR last_updated = '' "
        "OR (julianday('now') - julianday(last_updated)) >= 7.0);");
}

bool MarketCatalogService::toggleMarket(const std::string& marketName) {
    return runUpdate(
        database_.getHandle(),
        "UPDATE market_config "
        "SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END "
        "WHERE market_name = ?;",
        marketName);
}

bool MarketCatalogService::updateLastUpdated(const std::string& marketName) {
    return runUpdate(database_.getHandle(),
                     "UPDATE market_config "
                     "SET last_updated = date('now') "
                     "WHERE market_name = ?;",
                     marketName);
}

MarketSyncResult MarketCatalogService::syncMarket(const std::string& marketName) {
    return syncMarkets({marketName});
}

MarketSyncResult MarketCatalogService::syncActiveMarkets() {
    return syncMarkets(getActiveMarkets());
}

MarketSyncResult MarketCatalogService::autoUpdateStaleMarkets() {
    return syncMarkets(getMarketsNeedingAutoUpdate());
}

MarketSyncResult MarketCatalogService::syncMarkets(
    const std::vector<std::string>& marketNames) {
    MarketSyncResult result;

    for (const auto& marketName : marketNames) {
        auto& target =
            runSyncScript(marketName) && updateLastUpdated(marketName)
                ? result.syncedMarkets
                : result.failedMarkets;
        target.push_back(marketName);
    }

    return result;
}
