#pragma once

#include <string>
#include <vector>

// AI 모델 응답을 이용해 종목 관련 뉴스 검색 키워드를 추출하는 서비스다.
class KeywordExtractionService {
public:
    // symbolName과 market 정보를 프롬프트에 넣고 JSON 배열 형태의 키워드 목록으로 파싱한다.
    std::vector<std::string> extractKeywords(const std::string& symbolName,
                                             const std::string& market) const;
};
