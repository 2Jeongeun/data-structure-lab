#include "KeywordExtractionService.hpp"

#include "../../common/KeywordJsonParser.hpp"
#include "../../config/PromptConfig.hpp"
#include "../../model/NvidiaNimClient.hpp"

std::vector<std::string> KeywordExtractionService::extractKeywords(
    const std::string& symbolName,
    const std::string& market) const {
    // 프롬프트 템플릿을 채운 뒤 AI 응답을 JSON 키워드 배열로 해석한다.
    NvidiaNimClient ai;
    std::string prompt = PromptConfig::build(
        "keyword_extraction",
        {{"symbol", symbolName}, {"market", market}});
    std::string output = ai.callModel(prompt, true, PromptConfig::get("system"));
    return common::parseKeywordJson(output);
}
