#pragma once

#include <iostream>
#include <stdexcept>
#include <string>

#if __has_include(<QMessageBox>)
#include <QMessageBox>
#include <QWidget>
#define ERROR_HANDLER_HAS_QT 1
#endif

// DB 계층에서 발생한 예외임을 호출자에게 명확히 알려주는 전용 예외 타입이다.
class DatabaseException : public std::runtime_error {
public:
    explicit DatabaseException(const std::string& message)
        : std::runtime_error("[Database Error] " + message) {}
};

// 입력값 검증 실패를 일반 런타임 오류와 구분하기 위한 예외 타입이다.
class ValidationException : public std::runtime_error {
public:
    explicit ValidationException(const std::string& message)
        : std::runtime_error("[Validation Error] " + message) {}
};

// 외부 API 또는 네트워크 통신 실패를 표현하는 예외 타입이다.
class NetworkException : public std::runtime_error {
public:
    explicit NetworkException(const std::string& message)
        : std::runtime_error("[Network Error] " + message) {}
};

// 콘솔 실행과 Qt GUI 실행 모두에서 공통으로 사용하는 오류 처리 도우미다.
class ErrorHandler {
public:
    // 콘솔 환경에서는 표준 에러/출력으로 메시지를 남긴다.
    static void logError(const std::string& message) {
        std::cerr << "\n>>> [Error] " << message << std::endl;
    }

    static void handleException(const std::exception& e) {
        logError(e.what());
    }

    static void handleUnknownError() {
        logError("[Unknown Error] An unexpected error occurred.");
    }

    static void logWarning(const std::string& message) {
        std::cerr << "\n>>> [Warning] " << message << std::endl;
    }

    static void logInfo(const std::string& message) {
        std::cout << "\n>>> [Info] " << message << std::endl;
    }

#ifdef ERROR_HANDLER_HAS_QT
    // Qt가 사용 가능한 빌드에서는 사용자에게 메시지 박스를 보여준다.
    static void showWarning(QWidget* parent,
                            const QString& title,
                            const QString& message) {
        QMessageBox::warning(parent, title, message);
    }

    static void showInfo(QWidget* parent,
                         const QString& title,
                         const QString& message) {
        QMessageBox::information(parent, title, message);
    }

    static bool confirm(
        QWidget* parent,
        const QString& title,
        const QString& message,
        QMessageBox::StandardButton yesButton = QMessageBox::Yes,
        QMessageBox::StandardButton noButton = QMessageBox::No) {
        return QMessageBox::question(parent, title, message, yesButton | noButton) ==
               yesButton;
    }
#endif
};
