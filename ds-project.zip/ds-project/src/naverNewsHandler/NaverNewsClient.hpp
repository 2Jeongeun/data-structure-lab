#pragma once
#include <string>
#include <vector>

// 네이버 뉴스 검색 API에서 받은 기사 한 건의 주요 필드다.
struct NaverNewsArticle {
    std::string title;
    std::string link;
    std::string originalLink;
    std::string description;
    std::string pubDate;
};

// 네이버 뉴스 검색 API 호출을 담당하는 클라이언트다.
// 인증키는 생성자 인자, 환경 변수, key.json 순서로 찾는다.
class NaverNewsClient {
public:
    explicit NaverNewsClient(const std::string& clientId = "",
                             const std::string& clientSecret = "");
    std::vector<NaverNewsArticle> search(const std::string& query,
                                         int display = 5,
                                         const std::string& sort = "date");

private:
    std::string apiUrl;
    std::string clientId;
    std::string clientSecret;
};
