#pragma once
#include <string>

// NVIDIA NIM Chat Completions API를 호출하는 간단한 모델 클라이언트다.
// 현재 프로젝트에서는 종목명과 시장명을 바탕으로 뉴스 검색 키워드를 생성할 때 사용한다.
class NvidiaNimClient {
    std::string apiKey;
    std::string modelName;
    std::string apiUrl;

public:
    explicit NvidiaNimClient(const std::string& key = "");
    std::string callModel(const std::string& prompt,
                          bool jsonMode = false,
                          const std::string& systemPrompt = "");
};
