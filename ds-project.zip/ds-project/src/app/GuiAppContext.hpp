#pragma once

#include "../dataManage/news/NewsDatabase.hpp"
#include "../dataManage/wishlist/WishlistDatabase.hpp"
#include "../service/ai/KeywordExtractionService.hpp"
#include "../service/market/MarketCatalogService.hpp"
#include "../service/news/NewsCollectionService.hpp"
#include "../service/wishlist/WishlistWorkflowService.hpp"
#include "../symbolManage/SymbolListManager.hpp"

// GUI 실행에 필요한 DB와 서비스 객체를 한 곳에서 소유하고 조립한다.
// MainWindow는 이 컨텍스트에서 준비된 참조만 받아 화면 로직에 집중한다.
class GuiAppContext {
public:
    GuiAppContext();

    // DB 연결과 테이블 초기화를 실행한다.
    bool initialize();

    SymbolListManager& manager();
    MarketCatalogService& marketService();
    NewsCollectionService& newsService();
    WishlistWorkflowService& wishlistService();

private:
    WishlistDatabase wishlistDb_;
    SymbolListManager manager_;
    NewsDatabase newsDb_;
    MarketCatalogService marketService_;
    KeywordExtractionService keywordService_;
    NewsCollectionService newsService_;
    WishlistWorkflowService wishlistService_;
};
