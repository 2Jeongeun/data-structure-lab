#include "GuiAppContext.hpp"

#include "../errorHandler/ErrorHandler.hpp"

GuiAppContext::GuiAppContext()
    : wishlistDb_("data/wishlist/wishlist.db"),
      // 위시리스트 DB를 기반으로 핵심 매니저/서비스를 순서대로 조립한다.
      manager_(wishlistDb_),
      newsDb_("data/news/news.db"),
      marketService_(wishlistDb_),
      keywordService_(),
      newsService_(newsDb_),
      wishlistService_(manager_, keywordService_, newsService_) {}

bool GuiAppContext::initialize() {
    try {
        // GUI 실행 전에 필요한 로컬 DB를 모두 열고 기본 테이블을 준비한다.
        wishlistDb_.open();
        if (!manager_.initialize()) {
            ErrorHandler::logError("Failed to initialize wishlist tables for GUI.");
            return false;
        }

        newsDb_.open();
        // 뉴스 캐시 테이블이 없으면 여기서 최초 생성된다.
        if (!newsDb_.initializeTable()) {
            ErrorHandler::logError("Failed to initialize news tables for GUI.");
            return false;
        }

        return true;
    } catch (const std::exception& e) {
        ErrorHandler::logError("GUI app context initialization failed: " + std::string(e.what()));
        return false;
    }
}

SymbolListManager& GuiAppContext::manager() {
    return manager_;
}

MarketCatalogService& GuiAppContext::marketService() {
    return marketService_;
}

NewsCollectionService& GuiAppContext::newsService() {
    return newsService_;
}

WishlistWorkflowService& GuiAppContext::wishlistService() {
    return wishlistService_;
}
