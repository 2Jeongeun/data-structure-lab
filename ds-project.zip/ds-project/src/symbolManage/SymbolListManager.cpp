#include "SymbolListManager.hpp"

#include "../common/SqliteUtils.hpp"
#include "../dataManage/market/MarketDatabase.hpp"
#include "../errorHandler/ErrorHandler.hpp"

namespace {

constexpr auto kSymbolType = "symbol";
constexpr auto kKeywordType = "keyword";
constexpr auto kKeywordEdge = "has_keyword";

std::string symbolNodeKey(const std::string& code, const std::string& market) {
    // 시장이 다른 동일 티커를 구분하기 위해 "market:code" 형태로 키를 만든다.
    return market + ":" + code;
}

sqlite3_int64 ensureNode(sqlite3* db,
                         const std::string& type,
                         const std::string& nodeKey,
                         const std::string& label,
                         const std::string& code = "",
                         const std::string& market = "") {
    // 그래프 테이블에서 노드가 없으면 만들고, 있으면 기존 id를 다시 찾는다.
    sqlite_utils::Statement insertStmt(
        db,
        "INSERT OR IGNORE INTO graph_nodes "
        "(node_type, node_key, label, code, market) VALUES (?, ?, ?, ?, ?);");
    sqlite_utils::Statement selectStmt(
        db,
        "SELECT id FROM graph_nodes WHERE node_type = ? AND node_key = ?;");

    sqlite3_bind_text(insertStmt.stmt, 1, type.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(insertStmt.stmt, 2, nodeKey.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(insertStmt.stmt, 3, label.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(insertStmt.stmt, 4, code.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(insertStmt.stmt, 5, market.c_str(), -1, SQLITE_TRANSIENT);

    if (sqlite3_step(insertStmt.stmt) != SQLITE_DONE) {
        throw DatabaseException(
            "Failed to ensure node: " + std::string(sqlite3_errmsg(db)));
    }

    sqlite3_bind_text(selectStmt.stmt, 1, type.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(selectStmt.stmt, 2, nodeKey.c_str(), -1, SQLITE_TRANSIENT);

    if (sqlite3_step(selectStmt.stmt) == SQLITE_ROW) {
        return sqlite3_column_int64(selectStmt.stmt, 0);
    }

    throw DatabaseException("Failed to resolve node id for key: " + nodeKey);
}

std::vector<std::string> loadKeywords(sqlite3* db, int symbolId) {
    std::vector<std::string> out;
    // 심볼 노드와 연결된 키워드 노드를 읽어 현재 검색어 집합을 복원한다.
    sqlite_utils::Statement stmt(
        db,
        "SELECT k.label "
        "FROM graph_edges e "
        "JOIN graph_nodes k ON k.id = e.to_node_id "
        "WHERE e.from_node_id = ? AND e.edge_type = ? AND k.node_type = ? "
        "ORDER BY k.label COLLATE NOCASE;");

    sqlite3_bind_int(stmt.stmt, 1, symbolId);
    sqlite3_bind_text(stmt.stmt, 2, kKeywordEdge, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt.stmt, 3, kKeywordType, -1, SQLITE_STATIC);

    while (sqlite3_step(stmt.stmt) == SQLITE_ROW) {
        out.push_back(sqlite_utils::columnText(stmt.stmt, 0));
    }
    return out;
}

int countKeywordConsumers(sqlite3* db,
                          const std::string& sql,
                          const std::string& value,
                          const char* nodeType = kKeywordType) {
    sqlite_utils::Statement stmt(db, sql);
    sqlite3_bind_text(stmt.stmt, 1, kKeywordEdge, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt.stmt, 2, nodeType, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt.stmt, 3, value.c_str(), -1, SQLITE_TRANSIENT);
    return sqlite3_step(stmt.stmt) == SQLITE_ROW ? sqlite3_column_int(stmt.stmt, 0)
                                                 : 0;
}

int countSymbolNames(sqlite3* db, const std::string& value) {
    sqlite_utils::Statement stmt(
        db,
        "SELECT COUNT(*) FROM graph_nodes WHERE node_type = ? AND label = ?;");
    sqlite3_bind_text(stmt.stmt, 1, kSymbolType, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt.stmt, 2, value.c_str(), -1, SQLITE_TRANSIENT);
    return sqlite3_step(stmt.stmt) == SQLITE_ROW ? sqlite3_column_int(stmt.stmt, 0)
                                                 : 0;
}

}  // namespace

SymbolListManager::SymbolListManager(WishlistDatabase& db) : database(db) {}

bool SymbolListManager::initialize() {
    return database.initializeTables();
}

bool SymbolListManager::addSymbol(const Symbol& symbol) {
    auto* db = database.getHandle();
    if (!db) {
        ErrorHandler::logError("Wishlist symbol add failed: database handle is null.");
        return false;
    }

    try {
        const auto nodeKey = symbolNodeKey(symbol.code, symbol.market);
        sqlite_utils::Statement existsStmt(
            db,
            "SELECT id FROM graph_nodes WHERE node_type = ? AND node_key = ?;");
        sqlite3_bind_text(existsStmt.stmt, 1, kSymbolType, -1, SQLITE_STATIC);
        sqlite3_bind_text(existsStmt.stmt, 2, nodeKey.c_str(), -1, SQLITE_TRANSIENT);

        if (sqlite3_step(existsStmt.stmt) == SQLITE_ROW) {
            // 같은 시장의 같은 티커는 중복 저장하지 않는다.
            ErrorHandler::logWarning(
                "Symbol \"" + symbol.name + " (" + symbol.code + ") on " +
                symbol.market + "\" is already in your wishlist.");
            return false;
        }

        sqlite_utils::Transaction tx(db);
        auto symbolId =
            ensureNode(db, kSymbolType, nodeKey, symbol.name, symbol.code, symbol.market);

        for (const auto& keyword : symbol.keywords) {
            // 종목과 키워드를 간선으로 연결해 그래프 구조로 관리한다.
            auto keywordId = ensureNode(db, kKeywordType, keyword, keyword);
            sqlite_utils::Statement edgeStmt(
                db,
                "INSERT OR IGNORE INTO graph_edges "
                "(from_node_id, to_node_id, edge_type) VALUES (?, ?, ?);");
            sqlite3_bind_int64(edgeStmt.stmt, 1, symbolId);
            sqlite3_bind_int64(edgeStmt.stmt, 2, keywordId);
            sqlite3_bind_text(edgeStmt.stmt, 3, kKeywordEdge, -1, SQLITE_STATIC);

            if (sqlite3_step(edgeStmt.stmt) != SQLITE_DONE) {
                throw DatabaseException("Failed to link symbol to keyword: " + keyword);
            }
        }

        tx.commit();
        return true;
    } catch (const std::exception& e) {
        if (std::string(e.what()).find("UNIQUE constraint failed") !=
            std::string::npos) {
            ErrorHandler::logWarning(
                "Symbol \"" + symbol.name + " (" + symbol.code + ") on " +
                symbol.market + "\" is already in your wishlist.");
            return false;
        }

        ErrorHandler::logError("Symbol add failed: " + std::string(e.what()));
        return false;
    }
}

std::vector<Symbol> SymbolListManager::getWishlist() {
    std::vector<Symbol> out;
    auto* db = database.getHandle();
    if (!db) {
        return out;
    }

    try {
        sqlite_utils::Statement stmt(
            db,
            "SELECT id, label, code, market "
            "FROM graph_nodes WHERE node_type = ? ORDER BY id DESC;");
        sqlite3_bind_text(stmt.stmt, 1, kSymbolType, -1, SQLITE_STATIC);

        while (sqlite3_step(stmt.stmt) == SQLITE_ROW) {
            int id = sqlite3_column_int(stmt.stmt, 0);
            out.emplace_back(id,
                             sqlite_utils::columnText(stmt.stmt, 1),
                             sqlite_utils::columnText(stmt.stmt, 2),
                             sqlite_utils::columnText(stmt.stmt, 3),
                             loadKeywords(db, id));
        }
    } catch (const std::exception& e) {
        ErrorHandler::logError("Wishlist fetch failed: " + std::string(e.what()));
        out.clear();
    }

    return out;
}

std::vector<std::string> SymbolListManager::getSearchTerms(int symbolId) {
    std::vector<std::string> out;
    auto* db = database.getHandle();
    if (!db) {
        return out;
    }

    try {
        sqlite_utils::Statement stmt(
            db,
            "SELECT label FROM graph_nodes WHERE id = ? AND node_type = ?;");
        sqlite3_bind_int(stmt.stmt, 1, symbolId);
        sqlite3_bind_text(stmt.stmt, 2, kSymbolType, -1, SQLITE_STATIC);

        if (sqlite3_step(stmt.stmt) == SQLITE_ROW) {
            // 검색 시에는 종목명 자체도 첫 번째 검색어로 사용한다.
            out.push_back(sqlite_utils::columnText(stmt.stmt, 0));
        }

        auto keywords = loadKeywords(db, symbolId);
        out.insert(out.end(), keywords.begin(), keywords.end());
    } catch (const std::exception& e) {
        ErrorHandler::logError("Search term lookup failed: " + std::string(e.what()));
    }

    return out;
}

std::vector<std::string> SymbolListManager::updateSymbolKeywords(
    int symbolId,
    const std::vector<std::string>& nextKeywords) {
    std::vector<std::string> orphaned;
    auto* db = database.getHandle();
    if (!db) {
        ErrorHandler::logError("Keyword update failed: database handle is null.");
        return orphaned;
    }

    auto previousKeywords = loadKeywords(db, symbolId);
    if (previousKeywords.empty() && getSearchTerms(symbolId).empty()) {
        ErrorHandler::logWarning(
            "Keyword update skipped: no such symbol (id=" + std::to_string(symbolId) +
            ").");
        return orphaned;
    }

    try {
        sqlite_utils::Transaction tx(db);

        // 기존 키워드 연결을 모두 지운 뒤 새 집합으로 다시 연결한다.
        sqlite_utils::Statement clearStmt(
            db,
            "DELETE FROM graph_edges WHERE from_node_id = ? AND edge_type = ?;");
        sqlite3_bind_int(clearStmt.stmt, 1, symbolId);
        sqlite3_bind_text(clearStmt.stmt, 2, kKeywordEdge, -1, SQLITE_STATIC);

        if (sqlite3_step(clearStmt.stmt) != SQLITE_DONE) {
            throw DatabaseException("Failed to clear existing keyword edges.");
        }

        for (const auto& keyword : nextKeywords) {
            auto keywordId = ensureNode(db, kKeywordType, keyword, keyword);
            sqlite_utils::Statement edgeStmt(
                db,
                "INSERT OR IGNORE INTO graph_edges "
                "(from_node_id, to_node_id, edge_type) VALUES (?, ?, ?);");
            sqlite3_bind_int(edgeStmt.stmt, 1, symbolId);
            sqlite3_bind_int64(edgeStmt.stmt, 2, keywordId);
            sqlite3_bind_text(edgeStmt.stmt, 3, kKeywordEdge, -1, SQLITE_STATIC);

            if (sqlite3_step(edgeStmt.stmt) != SQLITE_DONE) {
                throw DatabaseException("Failed to attach keyword edge: " + keyword);
            }
        }

        tx.commit();
    } catch (const std::exception& e) {
        ErrorHandler::logError("Keyword update failed: " + std::string(e.what()));
        return orphaned;
    }

    for (const auto& keyword : previousKeywords) {
        if (std::find(nextKeywords.begin(), nextKeywords.end(), keyword) !=
            nextKeywords.end()) {
            continue;
        }

        try {
            const bool stillUsed =
                countKeywordConsumers(
                    db,
                    "SELECT COUNT(*) "
                    "FROM graph_edges e "
                    "JOIN graph_nodes k ON k.id = e.to_node_id "
                    "WHERE e.edge_type = ? AND k.node_type = ? AND k.label = ?;",
                    keyword) > 0;
            // 더 이상 어떤 종목도 쓰지 않는 키워드만 고아 검색어로 간주한다.
            if (!stillUsed && countSymbolNames(db, keyword) == 0) {
                orphaned.push_back(keyword);
            }
        } catch (const std::exception& e) {
            ErrorHandler::logError(
                "Keyword orphan check failed: " + std::string(e.what()));
        }
    }

    return orphaned;
}

std::vector<std::string> SymbolListManager::removeSymbol(int symbolId) {
    std::vector<std::string> orphaned;
    auto* db = database.getHandle();
    if (!db) {
        return orphaned;
    }

    auto terms = getSearchTerms(symbolId);
    if (terms.empty()) {
        ErrorHandler::logWarning(
            "No such symbol to remove (id=" + std::to_string(symbolId) + ").");
        return orphaned;
    }

    try {
        sqlite_utils::Transaction tx(db);
        // 심볼 노드를 지우면 연결 간선은 FK/CASCADE 설정에 따라 함께 정리된다.
        sqlite_utils::Statement deleteStmt(
            db,
            "DELETE FROM graph_nodes WHERE id = ? AND node_type = ?;");
        sqlite3_bind_int(deleteStmt.stmt, 1, symbolId);
        sqlite3_bind_text(deleteStmt.stmt, 2, kSymbolType, -1, SQLITE_STATIC);

        if (sqlite3_step(deleteStmt.stmt) != SQLITE_DONE) {
            throw DatabaseException("Failed to delete symbol node.");
        }

        tx.commit();
    } catch (const std::exception& e) {
        ErrorHandler::logError("Symbol removal failed: " + std::string(e.what()));
        return orphaned;
    }

    for (const auto& term : terms) {
        try {
            const bool stillUsed =
                countKeywordConsumers(
                    db,
                    "SELECT COUNT(*) "
                    "FROM graph_edges e "
                    "JOIN graph_nodes k ON k.id = e.to_node_id "
                    "WHERE e.edge_type = ? AND k.node_type = ? AND k.label = ?;",
                    term) > 0;
            // 삭제 후 남은 참조가 없다면 관련 뉴스 캐시도 같이 지워도 안전하다.
            if (!stillUsed && countSymbolNames(db, term) == 0) {
                orphaned.push_back(term);
            }
        } catch (const std::exception& e) {
            ErrorHandler::logError(
                "Orphan term check failed: " + std::string(e.what()));
        }
    }

    return orphaned;
}

std::vector<std::tuple<std::string, std::string, std::string>>
SymbolListManager::searchMarketSymbols(const std::vector<std::string>& markets,
                                       const std::string& query,
                                       int limit) {
    std::vector<std::tuple<std::string, std::string, std::string>> out;

    for (const auto& market : markets) {
        MarketDatabase db(market);
        if (!db.open()) {
            continue;
        }

        // 활성 시장들을 차례대로 훑어 같은 검색어 결과를 하나의 목록으로 합친다.
        for (const auto& pair : db.searchSymbols(query, limit)) {
            out.emplace_back(pair.first, pair.second, market);
        }
    }

    return out;
}
