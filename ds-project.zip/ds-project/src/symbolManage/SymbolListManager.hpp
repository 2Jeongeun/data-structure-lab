#pragma once

#include <string>
#include <tuple>
#include <vector>

#include "../dataManage/wishlist/WishlistDatabase.hpp"
#include "Symbol.hpp"

// 위시리스트 DB의 그래프 테이블을 이용해 종목과 키워드의 연결 관계를 관리한다.
// GUI/서비스 계층은 SQL을 직접 다루지 않고 이 클래스를 통해 종목 추가, 삭제, 검색을 수행한다.
class SymbolListManager {
    WishlistDatabase& database;

public:
    explicit SymbolListManager(WishlistDatabase& db);

    // 필요한 테이블과 기본 시장 설정을 준비한다.
    bool initialize();
    // 종목 노드와 키워드 노드, 두 노드 사이의 간선을 한 번에 저장한다.
    bool addSymbol(const Symbol& symbol);
    // 현재 위시리스트 전체를 Symbol 객체 목록으로 복원한다.
    std::vector<Symbol> getWishlist();
    // 특정 종목에 연결된 뉴스 검색어를 가져온다.
    std::vector<std::string> getSearchTerms(int symbolId);
    // 종목의 키워드 연결을 새 목록으로 교체하고 더 이상 사용하지 않는 키워드를 반환한다.
    std::vector<std::string> updateSymbolKeywords(
        int symbolId,
        const std::vector<std::string>& keywords);
    // 종목을 삭제하고 고아가 된 검색어를 반환해 뉴스 캐시 정리에 활용한다.
    std::vector<std::string> removeSymbol(int symbolId);
    // 활성화된 시장 DB들을 대상으로 종목명/티커 검색을 수행한다.
    std::vector<std::tuple<std::string, std::string, std::string>>
    searchMarketSymbols(
        const std::vector<std::string>& activeMarkets,
        const std::string& query,
        int limitPerMarket = 5);
};
