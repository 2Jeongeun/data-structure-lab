#pragma once
#include <string>
#include <vector>

// 위시리스트에 저장되는 하나의 금융 상품 정보를 표현한다.
// name/code/market은 종목 식별용이고, keywords는 관련 뉴스 검색어로 사용된다.
struct Symbol {
    int id;
    std::string name;
    std::string code;
    std::string market;
    std::vector<std::string> keywords;

    // DB에서 읽어 온 기존 종목처럼 이미 id가 있는 경우에 사용한다.
    Symbol(int id, std::string name, std::string code, std::string market, std::vector<std::string> keywords)
        : id(id), name(std::move(name)), code(std::move(code)), market(std::move(market)), keywords(std::move(keywords)) {}

    // 새로 추가할 종목은 아직 DB id가 없으므로 id를 0으로 둔다.
    Symbol(std::string name, std::string code, std::string market, std::vector<std::string> keywords)
        : id(0), name(std::move(name)), code(std::move(code)), market(std::move(market)), keywords(std::move(keywords)) {}
};
