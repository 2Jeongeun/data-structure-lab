#pragma once

#include <sqlite3.h>

#include <string>
#include <vector>

#include "../../naverNewsHandler/NaverNewsClient.hpp"

// 검색어별 뉴스 캐시를 SQLite 그래프 구조로 저장하는 DB 래퍼다.
class NewsDatabase {
public:
    // 이 시간 안에 수집된 뉴스는 API를 다시 호출하지 않고 캐시로 간주한다.
    static constexpr int DEFAULT_FRESHNESS_SECONDS = 6 * 3600;

    explicit NewsDatabase(const std::string& path = "data/news/news.db");
    ~NewsDatabase();

    bool open();
    void close();

    // 키워드 노드, 기사 노드, 두 노드의 연결 간선을 저장할 테이블을 준비한다.
    bool initializeTable();
    bool isFresh(const std::string& keyword,
                 int withinSeconds = DEFAULT_FRESHNESS_SECONDS);
    // 검색어와 기사 목록을 그래프 노드/간선으로 저장한다.
    bool saveNewsForKeyword(const std::string& keyword,
                            const std::vector<NaverNewsArticle>& articles);
    std::vector<NaverNewsArticle> getNewsForKeyword(const std::string& keyword);
    // 특정 검색어 캐시를 삭제하고 참조가 끊긴 기사 노드도 정리한다.
    bool deleteNewsForKeyword(const std::string& keyword);

private:
    std::string dbPath;
    sqlite3* db;
};
