#include "NewsDatabase.hpp"

#include "../../common/SqliteUtils.hpp"
#include "../../errorHandler/ErrorHandler.hpp"

namespace {

constexpr auto kKeywordType = "keyword";
constexpr auto kArticleType = "article";
constexpr auto kArticleEdge = "mentions_article";

// 키워드 노드가 없으면 만들고, 이후 기사 노드와 연결할 id를 반환한다.
sqlite3_int64 ensureKeywordNode(sqlite3* db, const std::string& keyword) {
    sqlite_utils::Statement insertStmt(
        db,
        "INSERT OR IGNORE INTO graph_nodes "
        "(node_type, node_key, label, fetched_at) VALUES (?, ?, ?, '');");
    sqlite_utils::Statement selectStmt(
        db,
        "SELECT id FROM graph_nodes WHERE node_type = ? AND node_key = ?;");

    sqlite3_bind_text(insertStmt.stmt, 1, kKeywordType, -1, SQLITE_STATIC);
    sqlite3_bind_text(insertStmt.stmt, 2, keyword.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(insertStmt.stmt, 3, keyword.c_str(), -1, SQLITE_TRANSIENT);

    if (sqlite3_step(insertStmt.stmt) != SQLITE_DONE) {
        throw DatabaseException(
            "Failed to ensure keyword node: " + std::string(sqlite3_errmsg(db)));
    }

    sqlite3_bind_text(selectStmt.stmt, 1, kKeywordType, -1, SQLITE_STATIC);
    sqlite3_bind_text(selectStmt.stmt, 2, keyword.c_str(), -1, SQLITE_TRANSIENT);

    if (sqlite3_step(selectStmt.stmt) == SQLITE_ROW) {
        return sqlite3_column_int64(selectStmt.stmt, 0);
    }

    throw DatabaseException("Failed to resolve keyword cache node.");
}

// 기사 URL을 우선 키로 쓰고, URL이 없을 때만 제목과 날짜를 조합해 고유 키를 만든다.
std::string articleNodeKey(const NaverNewsArticle& article) {
    if (!article.originalLink.empty()) {
        return article.originalLink;
    }
    if (!article.link.empty()) {
        return article.link;
    }
    return article.title + "|" + article.pubDate;
}

// 어떤 키워드와도 연결되지 않는 기사 노드를 삭제해 캐시 DB가 불필요하게 커지지 않게 한다.
void pruneOrphanArticles(sqlite3* db) {
    sqlite_utils::Statement stmt(
        db,
        "DELETE FROM graph_nodes "
        "WHERE node_type = ? "
        "AND id NOT IN (SELECT to_node_id FROM graph_edges WHERE edge_type = ?);");
    sqlite3_bind_text(stmt.stmt, 1, kArticleType, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt.stmt, 2, kArticleEdge, -1, SQLITE_STATIC);

    if (sqlite3_step(stmt.stmt) != SQLITE_DONE) {
        throw DatabaseException("Failed to delete orphan article nodes.");
    }
}

}  // namespace

NewsDatabase::NewsDatabase(const std::string& path) : dbPath(path), db(nullptr) {}

NewsDatabase::~NewsDatabase() {
    close();
}

bool NewsDatabase::open() {
    if (db) {
        return true;
    }
    sqlite_utils::openDatabase(db, dbPath, "news");
    return true;
}

void NewsDatabase::close() {
    if (db) {
        sqlite3_close(db);
        db = nullptr;
    }
}

bool NewsDatabase::initializeTable() {
    if (!db) {
        ErrorHandler::logError(
            "News graph initialization failed: handle is null. Call open() first.");
        return false;
    }

    try {
        // 뉴스 캐시는 키워드 노드와 기사 노드를 같은 테이블에 저장하는 그래프 구조다.
        sqlite_utils::exec(
            db,
            "CREATE TABLE IF NOT EXISTS graph_nodes ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "node_type TEXT NOT NULL,"
            "node_key TEXT NOT NULL,"
            "label TEXT NOT NULL,"
            "link TEXT NOT NULL DEFAULT '',"
            "original_link TEXT NOT NULL DEFAULT '',"
            "description TEXT NOT NULL DEFAULT '',"
            "pub_date TEXT NOT NULL DEFAULT '',"
            "fetched_at TEXT NOT NULL DEFAULT '',"
            "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,"
            "UNIQUE(node_type, node_key));",
            "News graph node schema");
        sqlite_utils::exec(
            db,
            "CREATE TABLE IF NOT EXISTS graph_edges ("
            "from_node_id INTEGER NOT NULL,"
            "to_node_id INTEGER NOT NULL,"
            "edge_type TEXT NOT NULL,"
            "ordinal INTEGER NOT NULL DEFAULT 0,"
            "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,"
            "PRIMARY KEY (from_node_id, to_node_id, edge_type),"
            "FOREIGN KEY (from_node_id) REFERENCES graph_nodes(id) ON DELETE CASCADE,"
            "FOREIGN KEY (to_node_id) REFERENCES graph_nodes(id) ON DELETE CASCADE);",
            "News graph edge schema");
        sqlite_utils::exec(
            db,
            "CREATE INDEX IF NOT EXISTS idx_news_nodes_type_key "
            "ON graph_nodes (node_type, node_key);",
            "News graph node index");
        sqlite_utils::exec(
            db,
            "CREATE INDEX IF NOT EXISTS idx_news_edges_type_from "
            "ON graph_edges (edge_type, from_node_id, ordinal);",
            "News graph edge index");
        return true;
    } catch (const std::exception& e) {
        ErrorHandler::logError(
            "News graph initialization failed: " + std::string(e.what()));
        return false;
    }
}

bool NewsDatabase::isFresh(const std::string& keyword, int withinSeconds) {
    if (!db) {
        return false;
    }

    try {
        // SQLite의 julianday를 사용해 마지막 수집 시점으로부터 지난 초를 계산한다.
        sqlite_utils::Statement stmt(
            db,
            "SELECT (julianday('now') - julianday(NULLIF(fetched_at, ''))) * 86400.0 "
            "FROM graph_nodes WHERE node_type = ? AND node_key = ?;");
        sqlite3_bind_text(stmt.stmt, 1, kKeywordType, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt.stmt, 2, keyword.c_str(), -1, SQLITE_TRANSIENT);

        if (sqlite3_step(stmt.stmt) == SQLITE_ROW &&
            sqlite3_column_type(stmt.stmt, 0) != SQLITE_NULL) {
            const double ageSeconds = sqlite3_column_double(stmt.stmt, 0);
            return ageSeconds >= 0.0 &&
                   ageSeconds < static_cast<double>(withinSeconds);
        }
    } catch (...) {
    }

    return false;
}

bool NewsDatabase::saveNewsForKeyword(
    const std::string& keyword,
    const std::vector<NaverNewsArticle>& articles) {
    if (!db) {
        ErrorHandler::logError("News save failed: handle is null.");
        return false;
    }

    try {
        sqlite_utils::Transaction tx(db);
        const auto keywordId = ensureKeywordNode(db, keyword);

        // 같은 검색어의 이전 기사 연결을 지운 뒤 새 검색 결과 순서대로 다시 연결한다.
        sqlite_utils::Statement deleteEdges(
            db,
            "DELETE FROM graph_edges WHERE from_node_id = ? AND edge_type = ?;");
        sqlite_utils::Statement upsertArticle(
            db,
            "INSERT INTO graph_nodes "
            "(node_type, node_key, label, link, original_link, description, pub_date, "
            "fetched_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now')) "
            "ON CONFLICT(node_type, node_key) DO UPDATE SET "
            "label = excluded.label, "
            "link = excluded.link, "
            "original_link = excluded.original_link, "
            "description = excluded.description, "
            "pub_date = excluded.pub_date, "
            "fetched_at = excluded.fetched_at;");
        sqlite_utils::Statement articleIdLookup(
            db,
            "SELECT id FROM graph_nodes WHERE node_type = ? AND node_key = ?;");
        sqlite_utils::Statement edgeInsert(
            db,
            "INSERT OR REPLACE INTO graph_edges "
            "(from_node_id, to_node_id, edge_type, ordinal) VALUES (?, ?, ?, ?);");
        sqlite_utils::Statement touchKeyword(
            db,
            "UPDATE graph_nodes SET fetched_at = datetime('now') WHERE id = ?;");

        sqlite3_bind_int64(deleteEdges.stmt, 1, keywordId);
        sqlite3_bind_text(deleteEdges.stmt, 2, kArticleEdge, -1, SQLITE_STATIC);
        if (sqlite3_step(deleteEdges.stmt) != SQLITE_DONE) {
            throw DatabaseException("Failed to clear cached keyword edges.");
        }

        pruneOrphanArticles(db);

        for (int i = 0; i < static_cast<int>(articles.size()); ++i) {
            const auto& article = articles[i];
            const auto nodeKey = articleNodeKey(article);

            sqlite_utils::reset(upsertArticle);
            sqlite3_bind_text(upsertArticle.stmt, 1, kArticleType, -1, SQLITE_STATIC);
            sqlite3_bind_text(
                upsertArticle.stmt, 2, nodeKey.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(
                upsertArticle.stmt, 3, article.title.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(
                upsertArticle.stmt, 4, article.link.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(upsertArticle.stmt,
                              5,
                              article.originalLink.c_str(),
                              -1,
                              SQLITE_TRANSIENT);
            sqlite3_bind_text(upsertArticle.stmt,
                              6,
                              article.description.c_str(),
                              -1,
                              SQLITE_TRANSIENT);
            sqlite3_bind_text(
                upsertArticle.stmt, 7, article.pubDate.c_str(), -1, SQLITE_TRANSIENT);
            if (sqlite3_step(upsertArticle.stmt) != SQLITE_DONE) {
                throw DatabaseException("Failed to upsert article node.");
            }

            sqlite_utils::reset(articleIdLookup);
            sqlite3_bind_text(articleIdLookup.stmt, 1, kArticleType, -1, SQLITE_STATIC);
            sqlite3_bind_text(
                articleIdLookup.stmt, 2, nodeKey.c_str(), -1, SQLITE_TRANSIENT);
            if (sqlite3_step(articleIdLookup.stmt) != SQLITE_ROW) {
                throw DatabaseException("Failed to resolve article node id.");
            }

            sqlite_utils::reset(edgeInsert);
            sqlite3_bind_int64(edgeInsert.stmt, 1, keywordId);
            sqlite3_bind_int64(
                edgeInsert.stmt, 2, sqlite3_column_int64(articleIdLookup.stmt, 0));
            sqlite3_bind_text(edgeInsert.stmt, 3, kArticleEdge, -1, SQLITE_STATIC);
            sqlite3_bind_int(edgeInsert.stmt, 4, i);
            if (sqlite3_step(edgeInsert.stmt) != SQLITE_DONE) {
                throw DatabaseException("Failed to connect keyword to article.");
            }
        }

        sqlite3_bind_int64(touchKeyword.stmt, 1, keywordId);
        if (sqlite3_step(touchKeyword.stmt) != SQLITE_DONE) {
            throw DatabaseException("Failed to update keyword freshness.");
        }

        tx.commit();
        return true;
    } catch (const std::exception& e) {
        ErrorHandler::logError("News save failed: " + std::string(e.what()));
        return false;
    }
}

bool NewsDatabase::deleteNewsForKeyword(const std::string& keyword) {
    if (!db) {
        return false;
    }

    try {
        // 키워드 노드를 삭제하면 FK cascade로 연결 간선이 함께 정리된다.
        sqlite_utils::Transaction tx(db);
        sqlite_utils::Statement findStmt(
            db,
            "SELECT id FROM graph_nodes WHERE node_type = ? AND node_key = ?;");
        sqlite_utils::Statement deleteStmt(
            db,
            "DELETE FROM graph_nodes WHERE id = ?;");

        sqlite3_bind_text(findStmt.stmt, 1, kKeywordType, -1, SQLITE_STATIC);
        sqlite3_bind_text(findStmt.stmt, 2, keyword.c_str(), -1, SQLITE_TRANSIENT);

        if (sqlite3_step(findStmt.stmt) != SQLITE_ROW) {
            tx.commit();
            return true;
        }

        sqlite3_bind_int64(deleteStmt.stmt, 1, sqlite3_column_int64(findStmt.stmt, 0));
        if (sqlite3_step(deleteStmt.stmt) != SQLITE_DONE) {
            throw DatabaseException("Failed to delete keyword cache node.");
        }

        pruneOrphanArticles(db);
        tx.commit();
        return true;
    } catch (const std::exception& e) {
        ErrorHandler::logError("News delete failed: " + std::string(e.what()));
        return false;
    }
}

std::vector<NaverNewsArticle> NewsDatabase::getNewsForKeyword(
    const std::string& keyword) {
    std::vector<NaverNewsArticle> out;
    if (!db) {
        return out;
    }

    try {
        // 저장 당시의 ordinal을 기준으로 API 결과 순서를 최대한 유지한다.
        sqlite_utils::Statement stmt(
            db,
            "SELECT a.label, a.link, a.original_link, a.description, a.pub_date "
            "FROM graph_nodes k "
            "JOIN graph_edges e ON e.from_node_id = k.id "
            "JOIN graph_nodes a ON a.id = e.to_node_id "
            "WHERE k.node_type = ? AND k.node_key = ? "
            "AND e.edge_type = ? AND a.node_type = ? "
            "ORDER BY e.ordinal ASC, a.id DESC;");
        sqlite3_bind_text(stmt.stmt, 1, kKeywordType, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt.stmt, 2, keyword.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt.stmt, 3, kArticleEdge, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt.stmt, 4, kArticleType, -1, SQLITE_STATIC);

        while (sqlite3_step(stmt.stmt) == SQLITE_ROW) {
            out.push_back({sqlite_utils::columnText(stmt.stmt, 0),
                           sqlite_utils::columnText(stmt.stmt, 1),
                           sqlite_utils::columnText(stmt.stmt, 2),
                           sqlite_utils::columnText(stmt.stmt, 3),
                           sqlite_utils::columnText(stmt.stmt, 4)});
        }
    } catch (const std::exception& e) {
        ErrorHandler::logError("News load failed: " + std::string(e.what()));
    }

    return out;
}
