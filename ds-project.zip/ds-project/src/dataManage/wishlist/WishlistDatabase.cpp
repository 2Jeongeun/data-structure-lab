#include "WishlistDatabase.hpp"

#include "../../common/SqliteUtils.hpp"
#include "../../errorHandler/ErrorHandler.hpp"

WishlistDatabase::WishlistDatabase(const std::string& path)
    : dbPath(path), db(nullptr) {}

WishlistDatabase::~WishlistDatabase() {
    close();
}

bool WishlistDatabase::open() {
    if (db) {
        return true;
    }
    sqlite_utils::openDatabase(db, dbPath, "wishlist");
    return true;
}

void WishlistDatabase::close() {
    if (db) {
        sqlite3_close(db);
        db = nullptr;
    }
}

sqlite3* WishlistDatabase::getHandle() const {
    return db;
}

bool WishlistDatabase::execute(const std::string& sql) {
    if (!db) {
        throw DatabaseException(
            "Wishlist database handle is null. Call open() first.");
    }
    sqlite_utils::exec(db, sql, "SQL execution failed");
    return true;
}

bool WishlistDatabase::initializeTables() {
    try {
        // 종목과 키워드를 모두 graph_nodes에 저장하고 graph_edges로 관계를 표현한다.
        for (const char* sql : {
                 "CREATE TABLE IF NOT EXISTS graph_nodes ("
                 "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                 "node_type TEXT NOT NULL,"
                 "node_key TEXT NOT NULL,"
                 "label TEXT NOT NULL,"
                 "code TEXT NOT NULL DEFAULT '',"
                 "market TEXT NOT NULL DEFAULT '',"
                 "payload TEXT NOT NULL DEFAULT '',"
                 "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,"
                 "UNIQUE(node_type, node_key));",
                 "CREATE TABLE IF NOT EXISTS graph_edges ("
                 "from_node_id INTEGER NOT NULL,"
                 "to_node_id INTEGER NOT NULL,"
                 "edge_type TEXT NOT NULL,"
                 "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,"
                 "PRIMARY KEY (from_node_id, to_node_id, edge_type),"
                 "FOREIGN KEY (from_node_id) REFERENCES graph_nodes(id) ON DELETE CASCADE,"
                 "FOREIGN KEY (to_node_id) REFERENCES graph_nodes(id) ON DELETE CASCADE);",
                 "CREATE INDEX IF NOT EXISTS idx_graph_nodes_type_key "
                 "ON graph_nodes (node_type, node_key);",
                 "CREATE INDEX IF NOT EXISTS idx_graph_nodes_type_label "
                 "ON graph_nodes (node_type, label);",
                 "CREATE INDEX IF NOT EXISTS idx_graph_edges_type_from "
                 "ON graph_edges (edge_type, from_node_id);",
                 "CREATE INDEX IF NOT EXISTS idx_graph_edges_type_to "
                 "ON graph_edges (edge_type, to_node_id);",
                 "CREATE TABLE IF NOT EXISTS market_config ("
                 "market_name TEXT PRIMARY KEY,"
                 "is_active INTEGER DEFAULT 0,"
                 "last_updated TEXT);",
             }) {
            execute(sql);
        }

        try {
            // 기존 DB 파일을 쓰는 사용자를 위해 last_updated 컬럼을 점진적으로 추가한다.
            execute("ALTER TABLE market_config ADD COLUMN last_updated TEXT;");
        } catch (...) {
        }

        // 기본 지원 시장은 처음 실행할 때 자동으로 활성화해 바로 검색 가능하게 한다.
        for (const char* sql : {
                 "INSERT OR IGNORE INTO market_config "
                 "(market_name, is_active, last_updated) VALUES ('krx', 1, '');",
                 "INSERT OR IGNORE INTO market_config "
                 "(market_name, is_active, last_updated) VALUES ('nasdaq', 1, '');",
                 "INSERT OR IGNORE INTO market_config "
                 "(market_name, is_active, last_updated) VALUES ('binance', 1, '');",
                 "INSERT OR IGNORE INTO market_config "
                 "(market_name, is_active, last_updated) VALUES ('bybit', 1, '');",
                 "INSERT OR IGNORE INTO market_config "
                 "(market_name, is_active, last_updated) VALUES ('china', 1, '');",
                 "INSERT OR IGNORE INTO market_config "
                 "(market_name, is_active, last_updated) VALUES ('europe', 1, '');",
                 "INSERT OR IGNORE INTO market_config "
                 "(market_name, is_active, last_updated) VALUES ('uk', 1, '');",
                 "INSERT OR IGNORE INTO market_config "
                 "(market_name, is_active, last_updated) VALUES ('commodity', 1, '');",
                 "UPDATE market_config SET is_active = 1;",
             }) {
            execute(sql);
        }

        return true;
    } catch (const std::exception& e) {
        ErrorHandler::logError(
            "Wishlist graph initialization failed: " + std::string(e.what()));
        return false;
    }
}
