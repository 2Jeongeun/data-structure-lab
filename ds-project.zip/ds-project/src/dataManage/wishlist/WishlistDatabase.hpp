#pragma once

#include <sqlite3.h>

#include <string>

// 사용자의 관심 종목, 키워드 그래프, 시장 설정을 저장하는 SQLite DB 래퍼다.
class WishlistDatabase {
    std::string dbPath;
    sqlite3* db;

public:
    explicit WishlistDatabase(const std::string& path = "data/wishlist/wishlist.db");
    ~WishlistDatabase();

    // DB 연결의 생명주기를 관리한다.
    bool open();
    void close();
    sqlite3* getHandle() const;
    // 공통 SQL 실행 함수로, 실패 시 예외를 던져 상위 계층에서 처리하게 한다.
    bool execute(const std::string& sql);
    // 그래프 노드/간선 테이블과 기본 시장 설정을 생성한다.
    bool initializeTables();
};
