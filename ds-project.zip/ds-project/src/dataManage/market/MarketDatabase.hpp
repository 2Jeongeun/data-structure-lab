#pragma once

#include <sqlite3.h>

#include <string>
#include <utility>
#include <vector>

// data/markets/*.db 파일 하나를 읽기 전용으로 열어 종목 검색을 수행한다.
class MarketDatabase {
    std::string marketName;
    std::string dbPath;
    sqlite3* db;

public:
    explicit MarketDatabase(const std::string& name);
    ~MarketDatabase();

    // 시장 DB는 외부 스크립트로 생성되므로 존재하지 않으면 false를 반환한다.
    bool open();
    void close();
    bool isAvailable() const;
    std::string getMarketName() const;
    // symbol 또는 name 컬럼에 검색어가 포함된 종목을 제한 개수만큼 반환한다.
    std::vector<std::pair<std::string, std::string>> searchSymbols(
        const std::string& query,
        int limit = 10);
};
