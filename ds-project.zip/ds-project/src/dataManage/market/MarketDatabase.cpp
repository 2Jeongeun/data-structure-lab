#include "MarketDatabase.hpp"

#include <filesystem>

MarketDatabase::MarketDatabase(const std::string& name)
    : marketName(name), dbPath("data/markets/" + name + ".db"), db(nullptr) {}

MarketDatabase::~MarketDatabase() {
    close();
}

bool MarketDatabase::open() {
    if (db) {
        return true;
    }
    // 시장 데이터 파일은 update_market.py가 만들어 두었을 때만 사용할 수 있다.
    if (!std::filesystem::exists(dbPath)) {
        return false;
    }

    if (sqlite3_open_v2(dbPath.c_str(), &db, SQLITE_OPEN_READONLY, nullptr) !=
        SQLITE_OK) {
        if (db) {
            sqlite3_close(db);
            db = nullptr;
        }
        return false;
    }

    return true;
}

void MarketDatabase::close() {
    if (db) {
        sqlite3_close(db);
        db = nullptr;
    }
}

bool MarketDatabase::isAvailable() const {
    return db != nullptr;
}

std::string MarketDatabase::getMarketName() const {
    return marketName;
}

std::vector<std::pair<std::string, std::string>> MarketDatabase::searchSymbols(
    const std::string& query,
    int limit) {
    std::vector<std::pair<std::string, std::string>> out;
    if (!db) {
        return out;
    }

    // LIKE 검색을 사용해 종목 코드와 회사명 둘 다에서 부분 일치를 찾는다.
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(
            db,
            "SELECT symbol, name FROM symbols "
            "WHERE symbol LIKE ? OR name LIKE ? LIMIT ?;",
            -1,
            &stmt,
            nullptr) != SQLITE_OK) {
        return out;
    }

    const std::string like = "%" + query + "%";
    sqlite3_bind_text(stmt, 1, like.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, like.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 3, limit);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        const char* symbol =
            reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
        const char* name =
            reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        if (symbol && name) {
            out.emplace_back(symbol, name);
        }
    }

    sqlite3_finalize(stmt);
    return out;
}
