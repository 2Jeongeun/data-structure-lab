# 📈 Global Stock & Crypto Symbol Wishlist Manager

이 프로젝트는 한국(KRX), 미국(NASDAQ), 유럽(Europe), 중국(China), 영국(UK) 주식시장은 물론 바이낸스(Binance) 및 바이비트(Bybit)의 가상자산(현물 및 선물) 시장, 그리고 원자재(Commodity) 시장의 **수만 개에 달하는 글로벌 종목 리스트를 선택적으로 동기화하고, 오타 없이 검색 및 선택하여 개인 위시리스트를 영속적으로 관리하는 C++ 기반 CLI 프로그램**입니다.

---

## 🏗️ 프로젝트 아키텍처

프로젝트는 데이터 성격에 따라 물리적 파일과 디렉토리를 격리(Partitioning)하고, C++ 객체지향 3레이어 구조를 통해 높은 모듈성과 낮은 결합도를 유지하고 있습니다.

```text
datastructure-project/
├── data/
│   ├── wishlist/
│   │   └── wishlist.db          <-- [개인 소장] 사용자 위시리스트 & 시장 설정 DB
│   └── markets/
│       ├── krx.db               <-- [읽기 전용] 한국 주식 마스터 DB
│       ├── nasdaq.db            <-- [읽기 전용] 미국 주식 마스터 DB
│       ├── binance.db           <-- [읽기 전용] 바이낸스 코인(현물/선물) 마스터 DB
│       ├── bybit.db             <-- [읽기 전용] 바이비트 코인(현물/선물) 마스터 DB
│       ├── china.db             <-- [읽기 전용] 중국 주식 마스터 DB
│       ├── europe.db            <-- [읽기 전용] 유럽 주식 마스터 DB
│       ├── uk.db                <-- [읽기 전용] 영국 주식 마스터 DB
│       └── commodity.db         <-- [읽기 전용] 주요 원자재 선물 마스터 DB
├── scripts/
│   └── update_market.py         <-- [동기화] 외부 API에서 종목을 긁어다 SQLite DB를 구축하는 Python 유틸리티
└── src/
    ├── dataManage/
    │   ├── wishlist/            <-- wishlist.db 연동 및 테이블 스키마 초기화 담당
    │   └── market/              <-- 개별 {market}.db 파일에 대한 다이나믹 READONLY LIKE 검색 담당
    ├── symbolManage/            <-- 서비스 레이어로, 위시리스트 비즈니스 로직 및 병렬 검색 담당
    └── main.cpp                 <-- CLI 콘솔 인터페이스 및 프로그램 흐름 제어 (UI Layer)
```

---

## 🛠️ 지금까지 완료된 작업 사항

### 1. 데이터베이스 파티셔닝 (물리 폴더 및 코드 분할)
* 가볍고 쓰기 빈도가 높은 개인 위시리스트(`wishlist.db`)와 수십만 레코드의 마스터 시장 종목 데이터(`markets/*.db`)를 물리적으로 분리했습니다.
* [Database.cpp](file:///Users/mavv/vsc-programming/datastructure-project/src/dataManage/Database.cpp) 단일 클래스를 삭제하고, [WishlistDatabase](file:///Users/mavv/vsc-programming/datastructure-project/src/dataManage/wishlist/WishlistDatabase.cpp) 및 [MarketDatabase](file:///Users/mavv/vsc-programming/datastructure-project/src/dataManage/market/MarketDatabase.cpp)로 접속 핸들러 코드를 도메인별로 완전히 격리했습니다.

### 2. 가상자산 현물 및 선물 마켓 통합 지원
* 바이비트 및 바이낸스의 현물(Spot)뿐만 아니라 **USDT-M/COIN-M/Linear Futures**의 전체 거래 페어까지 통합 동기화하도록 확장했습니다.
* 현물과 선물의 티커 중복으로 인한 SQLite `UNIQUE` 충돌 문제를 방지하기 위해 심볼 접미사(`_UM`, `_CM`, `_L`, `_I`) 파이썬 파싱 로직을 추가했습니다.

### 3. 통합 시장 고속 병렬 검색 구조
* 사용자가 종목 추가 시, 시장을 번거롭게 일일이 고를 필요 없이 곧장 검색어를 입력하면 **활성화된 모든 시장 데이터베이스를 대상으로 병합 검색**을 실시간으로 동시 수행합니다.
* 종목 코드(티커)와 종목명 두 영역에 대해 대소문자 무관하게 고속 `LIKE` 검색이 병렬적으로 수행되어 한 화면에 결과를 리스팅합니다.
* 추가 시 해당 종목이 어느 시장에서 유입되었는지(`market` 컬럼)를 메타데이터로 함께 저장 및 영속화하며, 위시리스트 조회 시 한눈에 볼 수 있도록 출력 테이블을 갱신했습니다.

### 4. 하위 호환성 및 안정성 설계
* **스키마 마이그레이션**: 기존에 `market` 컬럼 없이 생성된 구버전 `wishlist.db`가 로드되더라도 프로그램이 깨지지 않고 자동으로 구조를 갱신하도록 시동 루틴 예외 처리를 마련했습니다.
* **UTC 기준 7일 자동 업데이트**: 프로그램을 켤 때 마스터 데이터가 마지막으로 업데이트된 지 7일이 지났거나 비어있는 활성 시장에 대해서만 UTC 기준으로 자동 동기화합니다.
* **CLI 예외 처리**: 파이프라인이나 스크립트로 CLI 입력 시퀀스를 주입할 때 스트림이 끝나더라도 무한 루프에 빠지지 않도록 모든 `std::getline` 함수에 `EOF` 방어 코드를 구현했습니다.
* **AI 클라이언트 격리**: 추후 활용할 AI 모듈([NvidiaNimClient](file:///Users/mavv/vsc-programming/datastructure-project/src/model/NvidiaNimClient.cpp))을 소스 상에서는 완벽히 격리하되 빌드/컴파일 타깃에는 유지했습니다.

---

## 🚀 앞으로 작업하면 좋을 내용 (Future Roadmap)

1. **비동기 백그라운드 스레드 업데이트 (`std::thread`)**
   * 현재 시동 시 7일이 경과된 시장 데이터를 동기화할 때 Python 스크립트 실행으로 인해 약 3초 내외의 대기 지연이 발생합니다.
   * C++ `std::thread`를 사용하여 기동 시 기존 캐시 데이터를 즉시 화면에 띄우고, 백그라운드에서 동기화 작업을 조용히 수행하도록 구현하면 사용자 대기 시간을 0초로 줄일 수 있습니다.

2. **종목 카테고리(그룹)별 폴더링 기능**
   * 단순 리스트 형태의 위시리스트 대신 "배당주", "성장주", "롱포지션 코인" 등 사용자가 원하는 그룹 폴더를 지정하여 종목들을 카테고리별로 조회하고 정렬할 수 있는 데이터 모델 확장이 가능합니다.

3. **실시간 시세 연동 (C++ 웹소켓 통합)**
   * 위시리스트에 담긴 주식/코인의 실시간 시세를 외부 API 웹소켓(Websocket) 연결을 통해 C++ 터미널 화면에 실시간 갱신(Refresh)하며 시각화해 주는 기능입니다.

4. **SQLite 데이터 이중화 암호화 (SQLCipher)**
   * API Key 정보나 사용자의 개인 거래 내역 등 민감할 수 있는 로컬 위시리스트 데이터를 DB 파일 수준에서 강력히 암호화하는 보안 확장 기능을 추가합니다.
