#!/usr/bin/env python3
import os
import sys
import json
import urllib.request
import sqlite3
import re

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "markets")
os.makedirs(DATA_DIR, exist_ok=True)

def init_db(db_name):
    db_path = os.path.join(DATA_DIR, f"{db_name}.db")
    # Remove old DB to do a clean init
    if os.path.exists(db_path):
        os.remove(db_path)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS symbols (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL
        );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_symbol ON symbols(symbol);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_name ON symbols(name);")
    conn.commit()
    return conn

def insert_symbols(conn, items):
    cursor = conn.cursor()
    # Batch insert using transaction
    cursor.execute("BEGIN TRANSACTION;")
    for symbol, name in items:
        # Deduplicate and strip
        sym = symbol.strip()
        nm = name.strip()
        if not sym or not nm:
            continue
        try:
            cursor.execute("INSERT OR IGNORE INTO symbols (symbol, name) VALUES (?, ?);", (sym, nm))
        except Exception:
            pass
    conn.commit()

def fetch_krx():
    print("Fetching Korean stocks (KRX) from KIND...")
    url = "http://kind.krx.co.kr/corpgeneral/corpList.do?method=download"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('cp949', errors='ignore')
            
        # Parse simple HTML table using regex to avoid external dependency (BeautifulSoup)
        # Table rows look like: <tr> ... <td>회사명</td> ... <td>종목코드</td> ... </tr>
        rows = re.findall(r'<tr>(.*?)</tr>', html, re.DOTALL)
        items = []
        for row in rows:
            cols = re.findall(r'<td.*?>(.*?)</td>', row, re.DOTALL)
            if len(cols) >= 3:
                # First column is company name, third column is stock code
                name = re.sub(r'<.*?>', '', cols[0]).strip()
                code = re.sub(r'<.*?>', '', cols[2]).strip()
                # Clean whitespace/newlines
                name = re.sub(r'\s+', ' ', name)
                code = re.sub(r'\s+', '', code)
                # Exclude table headers like '회사명', '종목코드' (KRX codes are exactly 6 characters)
                if code and len(code) == 6:
                    items.append((code, name))
        return items
    except Exception as e:
        print(f"Error fetching KRX data: {e}")
        # Fallback dummy data if network or parsing fails
        return [("005930", "삼성전자"), ("000660", "SK하이닉스"), ("035420", "NAVER"), ("035720", "카카오")]

def fetch_nasdaq():
    print("Fetching US stocks (NASDAQ) from open repository...")
    # Using a reliable, open source JSON file containing NASDAQ tickers
    url = "https://raw.githubusercontent.com/rreichel3/US-Stock-Symbols/main/nasdaq/nasdaq_full_tickers.json"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        items = []
        for entry in data:
            symbol = entry.get("symbol")
            name = entry.get("name")
            if symbol and name:
                items.append((symbol, name))
        return items
    except Exception as e:
        print(f"Error fetching NASDAQ data: {e}")
        return [("AAPL", "Apple Inc."), ("MSFT", "Microsoft Corporation"), ("GOOGL", "Alphabet Inc."), ("AMZN", "Amazon.com, Inc.")]

def fetch_binance():
    print("Fetching Binance coin trading pairs (Spot + USD-M + COIN-M)...")
    items = []
    
    # 1. Fetch Spot
    try:
        url = "https://api.binance.com/api/v3/exchangeInfo"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        for symbol_info in data.get("symbols", []):
            if symbol_info.get("status") == "TRADING":
                symbol = symbol_info.get("symbol")
                base = symbol_info.get("baseAsset")
                quote = symbol_info.get("quoteAsset")
                items.append((symbol, f"{base}/{quote} (Binance Spot)"))
    except Exception as e:
        print(f"Error fetching Binance Spot: {e}")

    # 2. Fetch USD-M Futures
    try:
        url = "https://fapi.binance.com/fapi/v1/exchangeInfo"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        for symbol_info in data.get("symbols", []):
            if symbol_info.get("status") == "TRADING":
                symbol = symbol_info.get("symbol")
                base = symbol_info.get("baseAsset")
                quote = symbol_info.get("quoteAsset")
                items.append((symbol + "_UM", f"{base}/{quote} (Binance USD-M Futures)"))
    except Exception as e:
        print(f"Error fetching Binance USD-M Futures: {e}")

    # 3. Fetch COIN-M Futures
    try:
        url = "https://dapi.binance.com/dapi/v1/exchangeInfo"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        for symbol_info in data.get("symbols", []):
            if symbol_info.get("status") == "TRADING":
                symbol = symbol_info.get("symbol")
                base = symbol_info.get("baseAsset")
                quote = symbol_info.get("quoteAsset")
                items.append((symbol + "_CM", f"{base}/{quote} (Binance COIN-M Futures)"))
    except Exception as e:
        print(f"Error fetching Binance COIN-M Futures: {e}")

    if not items:
        return [("BTCUSDT", "BTC/USDT (Binance Spot)"), ("ETHUSDT", "ETH/USDT (Binance Spot)")]
    return items

def fetch_bybit():
    print("Fetching Bybit coin trading pairs (Spot + Linear + Inverse)...")
    items = []

    # 1. Fetch Spot
    try:
        url = "https://api.bybit.com/v5/market/instruments-info?category=spot"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        for item in data.get("result", {}).get("list", []):
            if item.get("status") == "Trading":
                symbol = item.get("symbol")
                base = item.get("baseCoin")
                quote = item.get("quoteCoin")
                items.append((symbol, f"{base}/{quote} (Bybit Spot)"))
    except Exception as e:
        print(f"Error fetching Bybit Spot: {e}")

    # 2. Fetch Linear (USDT perpetual / Futures)
    try:
        url = "https://api.bybit.com/v5/market/instruments-info?category=linear"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        for item in data.get("result", {}).get("list", []):
            if item.get("status") == "Trading":
                symbol = item.get("symbol")
                base = item.get("baseCoin")
                quote = item.get("quoteCoin")
                items.append((symbol + "_L", f"{base}/{quote} (Bybit Linear Perpetual)"))
    except Exception as e:
        print(f"Error fetching Bybit Linear: {e}")

    # 3. Fetch Inverse (Coin perpetual / Futures)
    try:
        url = "https://api.bybit.com/v5/market/instruments-info?category=inverse"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
        for item in data.get("result", {}).get("list", []):
            if item.get("status") == "Trading":
                symbol = item.get("symbol")
                base = item.get("baseCoin")
                quote = item.get("quoteCoin")
                items.append((symbol + "_I", f"{base}/{quote} (Bybit Inverse Perpetual)"))
    except Exception as e:
        print(f"Error fetching Bybit Inverse: {e}")

    if not items:
        return [("BTCUSDT", "BTC/USDT (Bybit Spot)"), ("ETHUSDT", "ETH/USDT (Bybit Spot)")]
    return items

def fetch_china():
    print("Fetching Chinese stocks (CSI 300) from Wikipedia...")
    url = "https://en.wikipedia.org/wiki/CSI_300_Index"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8')
        tables = re.findall(r'<table.*?class="wikitable.*?>(.*?)</table>', html, re.DOTALL)
        items = []
        if len(tables) >= 2:
            rows = re.findall(r'<tr>(.*?)</tr>', tables[1], re.DOTALL)
            for row in rows:
                cols = re.findall(r'<t[dh].*?>(.*?)</t[dh]>', row, re.DOTALL)
                if len(cols) >= 2:
                    raw_ticker = re.sub(r'<.*?>', '', cols[0]).strip()
                    name = re.sub(r'<.*?>', '', cols[1]).strip()
                    name = re.sub(r'\s+', ' ', name)
                    # Extract numeric digits from raw_ticker like "SSE: 600519" or "SZSE: 300750"
                    ticker_match = re.search(r'\d+', raw_ticker)
                    if ticker_match and name and raw_ticker != "Ticker":
                        ticker = ticker_match.group(0)
                        items.append((ticker, name))
        if items:
            return items
        raise Exception("Parsed empty list from Wikipedia CSI 300")
    except Exception as e:
        print(f"Error fetching China data: {e}")
        return [("600519", "Kweichow Moutai"), ("601318", "Ping An Insurance"), ("300750", "CATL")]

def fetch_europe():
    print("Fetching European stocks (Euro Stoxx 50) from Wikipedia...")
    url = "https://en.wikipedia.org/wiki/Euro_Stoxx_50"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8')
        tables = re.findall(r'<table.*?class="wikitable.*?>(.*?)</table>', html, re.DOTALL)
        items = []
        if len(tables) >= 3:
            rows = re.findall(r'<tr>(.*?)</tr>', tables[2], re.DOTALL)
            for row in rows:
                cols = re.findall(r'<t[dh].*?>(.*?)</t[dh]>', row, re.DOTALL)
                if len(cols) >= 3:
                    ticker = re.sub(r'<.*?>', '', cols[0]).strip()
                    name = re.sub(r'<.*?>', '', cols[2]).strip()
                    ticker = re.sub(r'\s+', '', ticker)
                    name = re.sub(r'\s+', ' ', name)
                    if ticker and name and ticker != "Ticker":
                        items.append((ticker, name))
        if items:
            return items
        raise Exception("Parsed empty list from Wikipedia Euro Stoxx 50")
    except Exception as e:
        print(f"Error fetching Europe data: {e}")
        return [("MC.PA", "LVMH Moët Hennessy Louis Vuitton"), ("ASML.AS", "ASML Holding N.V."), ("NESN.SW", "Nestlé S.A.")]

def fetch_uk():
    print("Fetching UK stocks (FTSE 100) from Wikipedia...")
    url = "https://en.wikipedia.org/wiki/FTSE_100_Index"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8')
        tables = re.findall(r'<table.*?id="constituents".*?>(.*?)</table>', html, re.DOTALL)
        items = []
        if tables:
            rows = re.findall(r'<tr>(.*?)</tr>', tables[0], re.DOTALL)
            for row in rows:
                cols = re.findall(r'<td.*?>(.*?)</td>', row, re.DOTALL)
                if len(cols) >= 2:
                    name = re.sub(r'<.*?>', '', cols[0]).strip()
                    ticker = re.sub(r'<.*?>', '', cols[1]).strip()
                    ticker = re.sub(r'\s+', '', ticker)
                    name = re.sub(r'\s+', ' ', name)
                    if ticker and name and ticker != "EPIC":
                        items.append((ticker, name))
        return items
    except Exception as e:
        print(f"Error fetching UK data: {e}")
        return [("AZN", "AstraZeneca"), ("SHEL", "Shell plc"), ("HSBA", "HSBC Holdings")]

def fetch_commodity():
    print("Generating Commodity market symbols...")
    return [
        ("GC=F", "Gold Futures (금 선물)"),
        ("SI=F", "Silver Futures (은 선물)"),
        ("CL=F", "Crude Oil Futures (크루드 오일 선물)"),
        ("NG=F", "Natural Gas Futures (천연가스 선물)"),
        ("BZ=F", "Brent Crude Oil Futures (브렌트유 선물)"),
        ("HG=F", "Copper Futures (구리 선물)"),
        ("PL=F", "Platinum Futures (백금 선물)"),
        ("PA=F", "Palladium Futures (팔라듐 선물)"),
        ("ZC=F", "Corn Futures (옥수수 선물)"),
        ("ZS=F", "Soybeans Futures (대두 선물)"),
        ("ZW=F", "Wheat Futures (밀 선물)"),
        ("CC=F", "Cocoa Futures (코코아 선물)"),
        ("KC=F", "Coffee Futures (커피 선물)"),
        ("CT=F", "Cotton Futures (면화 선물)"),
        ("SB=F", "Sugar Futures (설탕 선물)")
    ]

def sync_market(market_name):
    market_name = market_name.lower()
    if market_name == "krx":
        data = fetch_krx()
    elif market_name == "nasdaq":
        data = fetch_nasdaq()
    elif market_name == "binance":
        data = fetch_binance()
    elif market_name == "bybit":
        data = fetch_bybit()
    elif market_name == "china":
        data = fetch_china()
    elif market_name == "europe":
        data = fetch_europe()
    elif market_name == "uk":
        data = fetch_uk()
    elif market_name == "commodity":
        data = fetch_commodity()
    else:
        print(f"Unknown market: {market_name}")
        return False

    if data:
        conn = init_db(market_name)
        insert_symbols(conn, data)
        print(f"Successfully synced {len(data)} symbols for {market_name.upper()}.")
        conn.close()
        return True
    else:
        print(f"No symbols retrieved for {market_name.upper()}.")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 update_market.py <market_name|all>")
        sys.exit(1)
        
    target = sys.argv[1].lower()
    if target == "all":
        markets = ["krx", "nasdaq", "binance", "bybit", "china", "europe", "uk", "commodity"]
        for m in markets:
            sync_market(m)
    else:
        success = sync_market(target)
        sys.exit(0 if success else 1)
